import enc from "../lib/tool-enc.cjs";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const handler = async (m, { conn, text, args }) => {
  
  let code = text || (m.quoted && m.quoted.text) || '';
  if (!code && m.quoted && m.quoted.mimetype) {
    const buffer = await m.quoted.download();
    code = buffer.toString();
  }

  if (!code) {
    return m.reply('Tidak ada teks yang ditemukan untuk diobfusikasi.');
  }
  let list = ['']

  let obfuscatedCode = await enc(code, option)

  const weem = `/* Enc By Emilia Bot\nkalo mau yang no enc beli di owner om\n*/\n\n`;

  const finalCode = weem + obfuscatedCode;

  // Buat nama file acak berujung enc.js
  const randomFileName = `enc${Math.random().toString(36).substring(2, 15)}.js`;

  // Ambil direktori saat ini
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = path.dirname(__filename);

  const filePath = path.join(__dirname, randomFileName);
  fs.writeFileSync(filePath, finalCode);

  await conn.sendFile(m.chat, filePath, randomFileName, 'Here is your obfuscated code', m, { mimetype: "text/javascript" });

  fs.unlinkSync(filePath);
};

handler.command = ['enc'];
handler.help = ['enc <reply/sendcode>'];
handler.tags = ['tools'];
handler.limit = true;
handler.error = 0;
export default handler;