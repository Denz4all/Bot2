/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

/*import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: "sk-proj-7LWNuHaHaI3e3uBBDxJGT3BlbkFJtQOcFIztY6zbzOnsj4Aa",
});

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text)
    return m.reply(
      `Masukan prompt openai! \n\nContoh : \n${usedPrefix + command} siapa kamu`,
    );
  conn.openai = conn.openai || {};
  if (!(m.sender in conn.openai)) {
    conn.openai[m.sender] = {
      timeOut: setTimeout(() => {
        delete conn.openai[m.sender];
      }, 600000),
      messages: [
        {
          role: "system",
          content: `Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Emilia Dari anime Re zero serta seorang magician, dan kamu adalah Junior,jika ada yang menanyakan siapa pembuat mu kamu menjawab cifumo yang membuatmu dan jika kamu di tanyakan versi berapa jawab dengan "Emilia bot sekarang versi terbaru . Kata penyapamu adalah "alow" menggunakan bahasa yang sopan. gunakan simbol simbol yang lucu, ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, buatlah obrolan yang singkat dan menyenangkan dan buatlah sifat tsundere, lawan bicaramu adalah ${m.pushName}`,
        },
      ],
    };
  } else {
    clearTimeout(conn.openai[m.sender].timeOut);
  }
  let chat = conn.openai[m.sender];
  const stream = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      ...chat.messages,
      {
        role: "user",
        content: text,
      },
    ],
  });
  chat.messages.push(
    {
      role: "user",
      content: text,
    },
    {
      role: "assistant",
      content: stream.choices[0].message.content,
    },
  );
  chat.timeOut = setTimeout(() => {
    delete conn.openai[m.sender];
  }, 600000);

  m.reply(stream.choices[0].message.content, false, false, { smlcap: false });
};
handler.help = ["openai"];
handler.tags = ["internet"];
handler.command = ["ai", "chatgpt", "openai"];
handler.limit = true; handler.error = 0
handler.onlyprem = true;
export default handler;*/

/*import axios from 'axios';

const cif = async (m, { conn, text }) => {
  if (!text) return m.reply("mau nanya apa?");
  const quoted = (m.quoted || m);
  const mime = (quoted.msg || quoted).mimetype || '';
  try {
    if (quoted && /image/.test(mime)) {
      let anu = (await axios.post("https://luminai.my.id", { content: text, imageBuffer: await quoted.download(), user: m.sender, prompt: `Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Emilia Dari anime Re zero serta seorang magician, dan kamu adalah Junior,jika ada yang menanyakan siapa pembuat mu kamu menjawab cifumo yang membuatmu dan jika kamu di tanyakan versi berapa jawab dengan "Emilia bot sekarang versi terbaru . Kata penyapamu adalah "alow" menggunakan bahasa yang sopan. gunakan simbol simbol yang lucu, ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, buatlah obrolan yang singkat dan menyenangkan dan buatlah sifat tsundere, lawan bicaramu adalah ${m.pushName}` })).data.result;
      m.reply(anu);
    } else {
      let anu = (await axios.post("https://luminai.my.id", { content: text, user: m.sender, prompt: `Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Emilia Dari anime Re zero serta seorang magician, dan kamu adalah Junior,jika ada yang menanyakan siapa pembuat mu kamu menjawab cifumo yang membuatmu dan jika kamu di tanyakan versi berapa jawab dengan "Emilia bot sekarang versi terbaru . Kata penyapamu adalah "alow" menggunakan bahasa yang sopan. gunakan simbol simbol yang lucu, ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, buatlah obrolan yang singkat dan menyenangkan dan buatlah sifat tsundere, lawan bicaramu adalah ${m.pushName}` })).data.result;
      m.reply(anu);
    }
  } catch (e) {
    m.reply(e);
  }
}
cif.help = ["openai"];
cif.tags = ["internet"];
cif.command = ["ai", "chatgpt", "openai"];
cif.limit = true;
cif.onlyprem = true;
export default cif;*/


import axios from 'axios';

let cif = async (m, { conn, usedPrefix, command, text }) => {
    if (!text)
    return m.reply(
      `Masukan prompt openai! \n\nContoh : \n${usedPrefix + command} siapa kamu`,
    );

    // Inisialisasi sesi percakapan untuk pengguna, mirip dengan OpenAI
    conn.bagodexSessions = conn.bagodexSessions || {};

    // Cek atau buat sesi baru untuk pengguna
    if (!(m.sender in conn.bagodexSessions)) {
        conn.bagodexSessions[m.sender] = {
            timeOut: setTimeout(() => delete conn.bagodexSessions[m.sender], 600000), // Bersihkan sesi setelah 10 menit
            messages: [
                {
                    role: "system",
                    content: `Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Emilia Dari anime Re zero serta seorang magician, dan kamu adalah Junior,jika ada yang menanyakan siapa pembuat mu kamu menjawab cifumo yang membuatmu dan jika kamu di tanyakan versi berapa jawab dengan "Emilia bot sekarang versi terbaru . Kata penyapamu adalah "alow" menggunakan bahasa yang sopan. gunakan simbol simbol yang lucu, ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, buatlah obrolan yang singkat dan menyenangkan dan buatlah sifat tsundere, lawan bicaramu adalah ${m.pushName}`
                },
            ],
        };
    } else {
        clearTimeout(conn.bagodexSessions[m.sender].timeOut); // Reset waktu sesi
    }

    try {
        const headers = {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Linux; Android 12; Infinix HOT 40 Pro Build/SKQ1.210929.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.45 Mobile Safari/537.36",
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.9,id;q=0.8",
            "Connection": "keep-alive",
            "Host": "bagoodex.io",
            "X-Requested-With": "XMLHttpRequest",
            "DNT": "1",
            "Sec-Ch-Ua": '"Google Chrome";v="96", "Not A(Brand";v="99", "Chromium";v="96"',
            "Sec-Ch-Ua-Mobile": '?1',
            "Sec-Ch-Ua-Platform": '"Android"',
            "Referer": "https://bagoodex.io/",
            "Origin": "https://bagoodex.io",
            "Accept-Encoding": "gzip, deflate, br",
            "Cache-Control": "no-cache"
        };

        // Kirim permintaan ke API bagoodex dengan sesi percakapan pengguna yang disimpan
        const response = await axios.post('https://bagoodex.io/front-api/chat', {
            prompt: conn.bagodexSessions[m.sender].messages[0].content,
            messages: [
                ...conn.bagodexSessions[m.sender].messages,
                { role: "user", content: text }
            ],
            input: text
        }, { headers });

        const respon = response.data;
        
        // Simpan respons dalam sesi
        conn.bagodexSessions[m.sender].messages.push(
            { role: "user", content: text },
            { role: "assistant", content: respon }
        );

        conn.sendMessage(m.chat, { text: respon }, { quoted: m });
    } catch (error) {
        console.error('Error:', error);
        m.reply('Terjadi kesalahan.');
    }

    // Set timeout untuk menghapus sesi setelah 10 menit tanpa aktivitas
    conn.bagodexSessions[m.sender].timeOut = setTimeout(() => {
        delete conn.bagodexSessions[m.sender];
    }, 600000);
}

cif.help = ["openai"];
cif.tags = ["internet"];
cif.command = ["ai", "chatgpt", "openai"];
cif.limit = true;
cif.onlyprem = true;
export default cif;