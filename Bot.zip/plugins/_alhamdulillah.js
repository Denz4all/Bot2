const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = (await import('@adiwajshing/baileys')).default;

const handler = async (m, { conn, usedPrefix }) => {
  // Fungsi untuk membersihkan nomor dari karakter yang tidak diperlukan
  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '');
  }

  const userId = m.sender;

  // Waktu premium dalam milidetik (24 jam)
  const premiumDuration = 86400000; 
  const now = new Date().getTime();
  
  // Dapatkan hari saat ini
  const currentDate = new Date();
  const currentDay = currentDate.getDay(); // 0 = Minggu, 1 = Senin, ..., 5 = Jumat, 6 = Sabtu

  // Cek apakah hari ini adalah Jumat (5)
  if (currentDay !== 5) {
    return conn.reply(
      m.chat,
      `Perintah ini hanya dapat diakses pada hari *Jumat*. Silakan coba lagi pada hari Jumat.`,
      m
    );
  }

  // Inisialisasi jika pengguna tidak ada di database
  if (!global.db.data.users[userId]) {
    global.db.data.users[userId] = { premium: false, premiumDate: 0 };
  }

  // Cek apakah pengguna sudah memiliki akses premium
  if (global.db.data.users[userId].premium && now < global.db.data.users[userId].premiumDate) {
    // Jika pengguna masih memiliki akses premium aktif
    let remainingTime = global.db.data.users[userId].premiumDate - now;
    let premiumEndDate = msToDate(remainingTime);
    
    // Kirim pesan bahwa pengguna sudah memiliki premium aktif
    return conn.reply(
      m.chat,
      `Anda sudah memiliki akses premium aktif hingga *${premiumEndDate}*.\n\nSilakan tunggu sampai masa premium Anda habis sebelum mencoba mengaksesnya kembali.`,
      m
    );
  }

  // Set waktu premium ke waktu sekarang + 24 jam
  global.db.data.users[userId].premium = true; // Atur status premium
  global.db.data.users[userId].premiumDate = now + premiumDuration; // Atur waktu premium

  // Hitung waktu berakhirnya premium
  let remainingTime = global.db.data.users[userId].premiumDate - now;
  let premiumEndDate = msToDate(remainingTime);

  // Kirim balasan ke pengguna
  conn.reply(
    m.chat,
    `• *UPGRADE PREMIUM*\n\nAnda telah mendapatkan akses premium selama *24 jam*.\n\n*Premium hingga: ${premiumEndDate}*`,
    m
  );
};

// Fungsi untuk mengonversi milidetik ke format hari:jam:menit
function msToDate(ms) {
  let days = Math.floor(ms / (24 * 60 * 60 * 1000));
  let hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  let minutes = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
  
  // Menampilkan waktu yang tersisa dalam format yang lebih ramah
  return `${days} hari, ${hours} jam, ${minutes} menit`;
}

// Metadata handler
handler.command = /^(alhamdulillah)$/i;
handler.tags = ['premium'];
handler.help = ['alhamdulillah'];
handler.premium = false;  // Siapa saja dapat mengakses
handler.register = true;  // Pastikan pengguna terdaftar di database

export default handler;