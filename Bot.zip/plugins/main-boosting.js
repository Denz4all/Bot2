import { performance } from 'perf_hooks'

let handler = async (m, { conn }) => {
    // Pesan awal
    let start = `⚡ Boosting . . .`
    
    // Fungsi untuk menghasilkan angka acak yang berurutan, dengan jarak pergerakan progres yang lebih kecil
    function getRandomProgress(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;  // Hasilkan angka antara min dan max
    }

    // Buat array untuk progres loading dengan angka acak berurutan
    let progress = [];
    let lastProgress = 0;

    // Meningkatkan progres dengan jarak yang lebih kecil agar transisi lebih halus
    for (let i = 0; i < 6; i++) {
        // Setiap angka progres akan meningkat antara 10-20% dari progres sebelumnya
        let increment = getRandomProgress(10, 20);  // Jarak perubahan progres per langkah
        lastProgress = lastProgress + increment > 100 ? 100 : lastProgress + increment; // Tidak lebih dari 100%
        progress.push(lastProgress);
    }
    progress.push(100);  // Pastikan angka terakhir 100%

    // Buat array dari string loading dengan progres acak
    let loadd = progress.map(p => `《${'█'.repeat(p / 5)}${'▒'.repeat(20 - p / 5)}} ${p}%`);
    loadd.push('𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'); // Menambahkan status selesai

    // Kirim pesan loading pertama
    let { key } = await conn.sendMessage(m.chat, { text: start });

    // Update progres secara teratur
    for (let i = 0; i < loadd.length; i++) {
        await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
        await new Promise(resolve => setTimeout(resolve, 1000)); // Tunggu 1 detik sebelum update progres berikutnya
    }

    // Mengukur waktu eksekusi
    let old = performance.now()
    let neww = performance.now()
    let speed = `${neww - old}`

    // Kirim pesan hasil
    let finish = `✔️Berhasil mempercepat Bot hingga\n${speed} milisec!`
    conn.reply(m.chat, finish, m)
}

handler.help = ['boost', 'refresh']
handler.tags = ['info']
handler.command = /^boost|refresh/i

handler.fail = null
export default handler