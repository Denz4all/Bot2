/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

let handler = async (m, { conn }) => {
  if (!m.quoted) return m.reply("Where's the quoted message?");
  if (!m.quoted.mtype || m.quoted.mtype !== "viewOnceMessageV2") {
    return m.reply("This is not a View Once Message.");
  }

  if (global.db.data.settings[conn.user.jid]?.loading) {
    await m.reply(global.config.loading);
  }

  try {
    let msg, caption;

    // Check if it's an imageMessage or videoMessage
    if (m.quoted.imageMessage) {
      msg = await conn.downloadM(q.imageMessage, 'image'); // Download as image
      caption = await m.quoted.imageMessage.caption || "No caption available";
    } else if (m.quoted.videoMessage) {
      msg = await conn.downloadM(q.videoMessage, 'video'); // Download as video
      caption = await m.quoted.videoMessage.caption || "No caption available";
    } else {
      return m.reply("This is neither an image nor a video message.");
    }

    if (!msg) return m.reply("Failed to download the media.");

    // Send the downloaded file
    await conn.sendFile(m.chat, msg, '', caption, m);
  } catch (error) {
    m.reply("An error occurred while downloading the message.");
    console.error(error);
  }
};

handler.help = ["readviewonce"];
handler.tags = ["tools"];
handler.command = /^read(view(once)?)?|rvo$/i;

export default handler;