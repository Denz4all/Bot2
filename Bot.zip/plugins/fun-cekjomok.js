let handler = async (m, { conn }) => {

let who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender

const jomok = [
    "Ambatukam",
    "Ambatron",
    "Ambasing",
    "Ambamus Prime",
    "Rusdymus Prime",
    "Ambamer",
    "Amba wick 🔥",
    "Bunda rahma 😹",
    "Kakangku 😭",
    "An Ba Tu Kang",
    "Ambasis",
    "Ambappe",
    "Superstars jumbo cik 😹",
    "Ambatunat",
    "Roesdy newton",
    "Amba edison",
    "Albert imoet",
    "Vladimirtukam",
    "Xi imut",
    "Bung amba",
    "Julius rusdy",
    "Fuad kaisar jomokerto",
    "Mas fuad kuase tige",
    "Rusdypool",
    "Kaisar jomok",
    "Raja jomok",
    "Amba Bonaparte",
    "Spidermuani",
    "Ambaderman",
    "Ambapulator",
    "Mas Hardin tutorial pembuatan dodol khas garut",
    "Si imut kuase tige 😹",
    "Ambalytics",
    "Ambativasi",
    "Ambacong",
    "Ambaruwo ",
    "Ambaleon 🔥",
    "Rusdy shelby 🥶",
    "Herman bengkulu 77",
];

await conn.reply(m.chat, `kodam jomok ${await conn.getName(who)} adalah ${await pickRandom(jomok)} .`, m, {contextInfo: {mentionedJid: [who]}})
}
handler.help = handler.command = ["cekjomok"]
handler.tags = ["fun"]

export default handler 

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
}