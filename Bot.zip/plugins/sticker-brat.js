
/*
wa.me/6287815194609
github: https://github.com/cifumo
Instagram: https://instagram.com/tyoochann
Ini watermark gw cok jangan dihapus
*/
import { sticker } from '../lib/sticker.js'
import { run } from 'shannz-playwright'
import Jimp from 'jimp';

const handler = async (m, { conn, text }) => {
  if (!text) return m.reply('masukan teks nya!\n> Contoh: .brat Apalah')

  const anu = await brat(text);
  const buffer = anu // Mengambil buffer dari gambar yang dipotong
  const stik = await sticker(
    false,
    buffer,
    global.config.stickpack,
    global.config.stickauth,
  );
  conn.sendFile(m.chat, stik, false, false, m);
}
handler.help = ['brat'];
handler.tags = ['sticker'];
handler.command = ['brat']
handler.limit = true
export default handler;

/**
 * Fungsi untuk menjalankan Playwright dengan teks kustom dan memotong gambar
 * @param {string} customText - Teks yang ingin dimasukkan ke dalam input
 * @returns {Promise<Buffer>} - Buffer gambar yang sudah dipotong
 */
async function brat(customText) {
  const code = `
    const { chromium } = require('playwright');

    /*
    Wm Punya Yanz Dev
    */

    (async () => {
        const browser = await chromium.launch({ headless: true });
        const context = await browser.newContext({
            viewport: { width: 375, height: 812 },
            userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1'
        });

        const page = await context.newPage();
        await page.goto('https://www.bratgenerator.com/');
        
        // Setup theme
        await page.evaluate(() => {
            if (typeof setupTheme === 'function') setupTheme('white');
        });

        // Fill text input
        const textInput = \`${customText}\`;
        await page.fill('#textInput', textInput);

        // Accept cookies
        const cookieBtn = await page.$('#onetrust-accept-btn-handler');
        if (cookieBtn) await cookieBtn.click();

        await page.waitForTimeout(500);
        const clip = {
    x: 0,
    y: 100,
    width: 800,
    height: 500
  };

        // Take screenshot
        const screenshot = await page.screenshot({ path: 'screenshot.png', clip: clip });

        await browser.close();
        return screenshot;
    })();
    `;

  let screenshot = await run('javascript', code);
  let apalah = screenshot.result.files[0].publicURL;
  let tch = 'https://try.playwright.tech' + apalah;
  let kyah = await urlToBuffer(tch)
  return kyah
}