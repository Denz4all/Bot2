let handler = async (m, { conn, isOwner, isModerator }) => {
    // Check if the user is the owner or a moderator
    if (!isOwner && !isModerator) {
        return conn.reply(m.chat, 'Fitur ini hanya dapat digunakan oleh owner dan moderator.', m)
    }

    // Get the user ID from a tagged user, a quoted message, or the owner if no one is tagged/quoted
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : isOwner ? m.sender : null
    
    if (!users) {
        return m.reply('Tag pengguna yang ingin dijadikan admin atau balas pesan mereka.')
    }
    
    // Promote the user (tagged/quoted user or owner)
    await conn.groupParticipantsUpdate(m.chat, [users], 'promote')
    
    m.reply(`Done! @${users.split('@')[0]} telah menjadi admin.`, null, { mentions: [users] })
}

handler.help = ['jadiadmin']
handler.tags = ["owner"]
handler.command = /^(jadiadmin|miminin)$/i
handler.botAdmin = true
handler.group = true

export default handler

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))