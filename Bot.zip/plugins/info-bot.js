import fetch from 'node-fetch'
import fs from 'fs'

let handler = async (m, { conn, generateWAMessageFromContent }) => {
  let loadd = [
    "「▱▱▱▱▱▱▱▱▱▱」Loading...",
    "「▰▱▱▱▱▱▱▱▱▱」Loading...",
    "「▰▰▱▱▱▱▱▱▱▱」Loading...",
    "「▰▰▰▱▱▱▱▱▱▱」Loading...",
    "「▰▰▰▰▱▱▱▱▱▱」Loading...",
    "「▰▰▰▰▰▱▱▱▱▱」Loading...",
    "「▰▰▰▰▰▰▱▱▱▱」Loading...",
    "「▰▰▰▰▰▰▰▱▱▱」Loading...",
    "「▰▰▰▰▰▰▰▰▱▱」Loading...",
    "「▰▰▰▰▰▰▰▰▰▱」Loading...",
    "「▰▰▰▰▰▰▰▰▰▰」Loading...",
    "Sukses Infobot akan dikirimkan ke " + m.sender.split('@')[0], // Menampilkan pengirim
  ];

  // Mengirim pesan pertama "Loading..."
  let { key } = await conn.sendMessage(m.chat, { text: 'Loading...' });

  // Mengedit pesan loading dengan progres
  for (let i = 0; i < loadd.length; i++) {
    await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
    await new Promise(resolve => setTimeout(resolve, 1000)); // Menunggu 1 detik sebelum update pesan berikutnya
  }

  // Informasi bot
  let { anon, anticall, antispam, antitroli, backup, jadibot, groupOnly, nsfw, statusupdate, autogetmsg, antivirus, publicjoin } = global.db.data.settings[conn.user.jid];
  const chats = Object.keys(await conn.chats);
  const groups = Object.keys(await conn.groupFetchAllParticipating());
  const block = await conn.fetchBlocklist();

  let tag = `@${m.sender.replace(/@.+/, '')}`;
  let mentionedJid = [m.sender];
  let _uptime = process.uptime() * 1000;
  let uptime = clockString(_uptime);
  let sts = ` – Info Bot Seo nari

┌ ◦ ᴀᴋᴛɪғ sᴇʟᴀᴍᴀ ${uptime}
│ ◦ ${groups.length} ɢʀᴜᴘ
│ ◦ ${chats.length - groups.length} ᴄʜᴀᴛ ᴘʀɪʙᴀᴅɪ
│ ◦ ${Object.keys(global.db.data.users).length} ᴘᴇɴɢɢᴜɴᴀ
│ ◦ ${block == undefined ? '*0* ᴅɪʙʟᴏᴄᴋɪʀ' : '*' + block.length + '* ᴅɪʙʟᴏᴄᴋɪʀ'}
│ ◦ ${Object.entries(global.db.data.chats).filter(chat => chat[1].isBanned).length} ᴄʜᴀᴛ ᴛᴇʀʙᴀɴɴᴇᴅ
└ ◦ ${Object.entries(global.db.data.users).filter(user => user[1].banned).length} ᴘᴇɴɢɢᴜɴᴀ ᴛᴇʀʙᴀɴɴᴇᴅ

Seo nari`;

  // Mengirim informasi bot dalam format teks
  await conn.sendMessage(m.chat, { text: sts });

};

handler.help = ['botstatus'];
handler.tags = ['info'];
handler.command = /^(infobot|botstatus|statusbot)?$/i;

export default handler;

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
}