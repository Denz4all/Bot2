/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

/* dibuat oleh Cifumo
owner: https://wa.me/6283114439876
bot: https://wa.me/6283151441108
ig: https://instagram.com/tyoochann
github: - */

let handler = async (m, { conn, text, usedPrefix, command }) => {
  conn.listAfk = conn.listAfk || {}; // Initialize the AFK list if it doesn't exist

  try {
    // Build the AFK list for the chat
    const caption = `*LIST AFK for Chat:* ${await conn.getName(m.chat)}\n\n` +
      // Iterate through the list of AFK users for the specific chat
      `${(conn.listAfk[m.chat] || []).map((v, i) => {
        // Retrieve the user information from global db
        const user = global.db.data.users[v.id];
        return `*${i + 1}.*  - *Name:* ${v.username}\n     - *ID:* @${v.id.split("@")[0]}\n     - *Time:* ${formatDateDetails(user.afk)}\n     - *Reason:* ${user.afkReason || 'No reason'}`;
      }).join("\n\n") || "No users in the list."}`;

    // Send the AFK list with mentions for users in the list
    await conn.reply(m.chat, caption, null, {
      contextInfo: {
        mentionedJid: (conn.listAfk[m.chat] || []).map((v) => v.id), // Mention the AFK users
        externalAdReply: {
          title: "AFK List",
          thumbnail: await (
            await conn.getFile(
              "https://cdn-icons-png.flaticon.com/128/6012/6012311.png"
            )
          ).data,
        },
      },
    });
  } catch (error) {
    console.error(error);
  }
};
handler.help = ["listafk"];
handler.tags = ["main"];
handler.group = true;
handler.command = /^(listafk)$/i;

export default handler;

// Function to format the AFK date in a readable format
function formatDateDetails(date) {
  const options = {
    timeZone: "Asia/Jakarta",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  };

  return new Intl.DateTimeFormat("id-ID", options).format(date);
}