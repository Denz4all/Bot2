import fs from "fs";
import syntaxError from "syntax-error";
import path from "path";

const _fs = fs.promises;

let handler = async (m, { text, usedPrefix, command, __dirname }) => {
  let input = `[!] Wrong input\n\nExample: ${usedPrefix + command} example.js`;
  if (!text) return m.reply(input);
  if (!m.quoted) return m.reply("Balas/quote media atau teks yang ingin disimpan.");

  const wem = `
/*
wa.me/${global.info?.nomorown || "YourNumberHere"}
github: https://github.com/cifumo
Instagram: https://instagram.com/tyoochann
Ini watermark gw cok jangan dihapus
*/
`;

  if (/p(lugin)?/i.test(command)) {
    // Jika perintah adalah plugin
    let filename = text.replace(/plugin(s)\//i, "") + (/\.js$/i.test(text) ? "" : ".js");
    const error = syntaxError(m.quoted.text, filename, {
      sourceType: "module",
      allowReturnOutsideFunction: true,
      allowAwaitOutsideFunction: true,
    });
    if (error) throw error;

    const pathFile = path.join(__dirname, filename);
    if (fs.existsSync(pathFile)) {
      return m.reply(`File ${filename} sudah ada. Ganti nama file.`);
    }
    await _fs.writeFile(pathFile, wem + m.quoted.text);
    m.reply(`Successfully saved to ${filename}`);
  } else {
    // Untuk jenis file lainnya
    const isJavascript =
      m.quoted.text && !m.quoted.mediaMessage && /\.js$/i.test(text);
    if (isJavascript) {
      const error = syntaxError(m.quoted.text, text, {
        sourceType: "module",
        allowReturnOutsideFunction: true,
        allowAwaitOutsideFunction: true,
      });
      if (error) throw error;
      await _fs.writeFile(text, wem + m.quoted.text);
      m.reply(`Successfully saved to ${text}`);
    } else if (m.quoted.mediaMessage) {
      const media = await m.quoted.download();
      await _fs.writeFile(text, media);
      m.reply(`Successfully saved media to ${text}`);
    } else {
      throw "Not supported!";
    }
  }
};

handler.help = ["plugin", "scraper"].map((v) => `save ${v} <name file>`);
handler.tags = ["owner"];
handler.command = /^(save|sf)$/i;
handler.owner = true;

export default handler;