/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

let handler = async (m, { conn }) => {
  let tqto = `
> Rey Osaka (Support)
> Cifumo (Recode)
> Rodotz (Support)
> Bochil Team (Base script)

Script Emilia - Bot Di Recode Oleh: *Cifumo*
`;

  await conn.sendButton2(
    m.chat,
    "Terimakasih kepada",
    tqto,
    wm,
    ["Owner", ".owner"],
    m,
  );
};

handler.menuinfo = ["tqto"];
handler.tagsinfo = ["info"];
handler.command = /^(tqto)$/i;
handler.register = true;
export default handler;
