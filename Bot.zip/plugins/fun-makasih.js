const handler = async (m, { conn }) => {
  // Daftar balasan acak
  const responses = [
    "Sama-sama~ 💖",
    "Hehe, sama-sama yaa~ 😸",
    "Wkwk, sama-sama~ 😋",
    "Sama-sama, semoga hari kamu menyenangkan! ✨",
    "Sama-sama, nggak masalah kok! 😌",
    "Sama-sama, semoga kamu selalu bahagia yaa~ 🌸",
    "Ya, sama-sama~ 🥰",
    "Sama-sama, kamu lucu banget deh~ 😚",
    "Sama-sama! Seneng banget bisa bantuin! 😽",
    "Kamu sangat dihargai~ 💖 Sama-sama! 😊"
  ];

  // Periksa apakah pesan mengandung salah satu ucapan terima kasih
  if (/(terima\s?kasi|makasih|makasihhh|makasiii|makasii|makasi|makaciii|makacii|makaci|terimakaciii)/i.test(m.text)) {
    // Pilih balasan acak
    const response = responses[Math.floor(Math.random() * responses.length)];
    // Kirim balasan
    await conn.reply(m.chat, response, m);
  }
};

// Menambahkan prefix custom
handler.customPrefix = /(terima\s?kasi|makasih|makasihhh|makasiii|makasii|makasi|makaciii|makacii|makaci|terimakaciii)/i;
handler.command = new RegExp;

export default handler;