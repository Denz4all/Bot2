/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

import fs from "fs";
let handler = async (m, { conn }) => {
  let teks = `
❏ *_Harga Premium_*
❃ _15 Hari / 10k_
❃ _30 Hari / 25k_
❃ _45 Hari / 35k_
❃ _60 Hari / 45k_
❃ _120 hari / 75k_
❃ _Permanen / 90k_

❏ *_Fitur_*
❃ _Unlimited Limit_
❃ _Nsfw_
❃ _Bebas Pakai Bot Di Pc_
❃ _Dan Lain Lain_

Minat? Silahkan Chat Nomor Owner Dibawah 
${global.config.owner
  .map(([jid, name]) => {
    return `
Name : ${name}
https://wa.me/${jid}
`.trim();
  })
  .join("\n\n")}
`.trim();
  await conn.adReply(
    m.chat,
    teks,
    "U P G R A D E - P R E M I U M",
    "",
    fs.readFileSync("./media/thumbnail.jpg"),
    global.config.website,
    m,
  );
};
handler.help = ["premium"];
handler.tags = ["main"];
handler.command = /^prem(ium)?$/i;

export default handler;