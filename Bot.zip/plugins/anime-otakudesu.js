/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

import { anime } from "../lib/anime.js";
import axios from "axios";
import fs from "fs";

let handler = async (m, { conn, usedPrefix, command, text, isPrems }) => {
  if (!text)
    return m.reply(
      `Masukan Query Atau Link!\n\nContoh :\n${usedPrefix + command} Tonikaku Kawai\n${usedPrefix + command} https://otakudesu.cloud/anime/tonikaku-ni-kawaii-sub-indo/`,
    );
  let d = new Date(new Date() + 3600000);
  let locale = "id";
  let date = d.toLocaleDateString(locale, {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  let url = text.startsWith("http") ?
    text.replace(/http(s)?:\/\//i, "").split("/")[1] :
    text;
  if (/^anime/i.test(url)) {
    global.db.data.settings[conn.user.jid].loading ?
      await m.reply(global.config.loading) :
      false;
    let result = await anime.otakudesu.detail(text);
    let teks = `
Title : ${result.judul}
Score : ${result.skor}
Produser : ${result.produser}
Status : ${result.status}
Total Eps : ${result.total_episode}
Durasi : ${result.durasi}
Tanggal Rilis : ${result.tanggal_rilis}
Studio : ${result.studio}
Genre : ${result.genre}
`.trim();
    let rows = result.episode.map((ep) => ({
      title: ep.judul,
      description: ep.upload,
      id: `${usedPrefix}otakudesu ${ep.link}`,
    }));

    let buttonMsg = {
      title: result.judul,
      sections: [
        {
          title: "Episode List",
          rows: rows,
        },
      ],
    };

    let buttons = [
      {
        name: "single_select",
        buttonParamsJson: JSON.stringify(buttonMsg),
      },
    ];

    conn.sendButtonImg(
      m.chat,
      result.image,
      "",
      teks,
      global.config.watermark,
      buttons,
      m,
    );
  } else if (/^episode/i.test(url)) {
    global.db.data.settings[conn.user.jid].loading ?
      await m.reply(global.config.loading) :
      false;
    let result = await anime.otakudesu.episode(text);

    let downloadLinks = [];
    for (let download of result.download) {
      let pdrainLink = download.links.find(link => /pdrain/i.test(link.name));
      let megaLink = download.links.find(link => /mega/i.test(link.name));

      if (pdrainLink) {
        downloadLinks.push({
          type: download.type,
          link: await originalUrl(pdrainLink.link),
          source: 'pixeldrain'
        });
      } else if (megaLink) {
        downloadLinks.push({
          type: download.type,
          link: await originalUrl(megaLink.link),
          source: 'mega'
        });
      }
    }

    let rows = downloadLinks.map((dl) => ({
      title: `Download Resolusi ${dl.type}`,
      description: "",
      id: `.${dl.source} ${dl.link}`
    }));

    let buttonMsg = {
      title: "Click Here",
      sections: [
        {
          title: "Otakudesu Search",
          highlight_label: "Popular",
          rows: rows,
        },
      ],
    };

    let buttons = [
      {
        name: "single_select",
        buttonParamsJson: JSON.stringify(buttonMsg),
      },
    ];

    conn.sendButton(
      m.chat,
      "",
      "Silahkan pilih resolusi video dibawah",
      global.config.watermark,
      buttons,
      m,
    );
  } else {
    global.db.data.settings[conn.user.jid].loading ?
      await m.reply(global.config.loading) :
      false;
    let result = await anime.otakudesu.search(text);
    let rows = [];
    for (let i = 0; i < result.length; i++) {
      let results = {
        header: "",
        title: result[i].title,
        description: `${result[i].genres} - ${result[i].status}`,
        id: usedPrefix + "otakudesu " + result[i].link,
      };
      rows.push(results);
    }
    let buttonMsg = {
      title: "Click Here",
      sections: [
        {
          title: "Otakudesu Search",
          highlight_label: "Popular",
          rows: rows,
        },
      ],
    };
    let buttons = [
      {
        name: "single_select",
        buttonParamsJson: JSON.stringify(buttonMsg),
      },
    ];
    conn.sendButtonImg(
      m.chat,
      result[0].thumbnail,
      "",
      "Silahkan pilih anime yang anda cari dibawah",
      global.config.watermark,
      buttons,
      m,
    );
  }
};
handler.help = ["otakudesu"];
handler.tags = ["anime"];
handler.command = /^(otakudesu)$/i;
handler.limit = true;
handler.error = 0
export default handler;

async function originalUrl(url) {
  return (await axios(url)).request.res.responseUrl;
}

const delay = (time) => new Promise((res) => setTimeout(res, time));