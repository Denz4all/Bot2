import axios from 'axios';
import uploadImage from "../lib/uploadFile.js";

let handler = async (m, { conn, usedPrefix, command, text }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  if (!mime) return m.reply("Fotonya Mana?");
  if (!/image\/(jpe?g|png)/.test(mime))
    return m.reply(`Tipe ${mime} tidak didukung!`);
  let ephemeral =
    conn.chats[m.chat]?.metadata?.ephemeralDuration ||
    conn.chats[m.chat]?.ephemeralDuration ||
    false;
  global.db.data.settings[conn.user.jid].loading
    ? await m.reply(global.config.loading)
    : false;
  let img = await q.download();
  let files = await uploadImage(img);
  
  switch (command) {
    case "removebg": {
      try {
        let out = await removebg(files);
        await conn.sendMessage(
          m.chat,
          {
            image: { url: out },
            fileName: "removebg.png",
            mimetype: "image/png",
            caption: "*DONE (≧ω≦)ゞ*",
          },
          { quoted: m, ephemeralExpiration: ephemeral },
        );
      } catch (e) {
        console.error(e);
        m.reply('Terjadi kesalahan saat menghapus latar belakang.');
      }
      break;
    }
    case "changebg": {
      let out = await removebg(files);
      await conn.sendFile(m.chat, out, "out.png", "*DONE (≧ω≦)ゞ*", m);
      break;
    }
    default:
      return;
  }
};
handler.help = ["removebg", "changebg"];
handler.tags = ["tools", "premium"];
handler.command = /^(removebg|changebg)$/i;
handler.premium = true; handler.error = 0
export default handler;

async function removebg(url, color = false) {
  try {
    const response = await axios.post('https://api.itsrose.rest/image/rembg', 
      { init_image: url },
      {
        headers: {
          'accept': 'application/json',
          'Authorization': APIKeys[APIs['rose']],
          'Content-Type': 'application/json'
        }
      });

    if (response.data.status && response.data.result && response.data.result.images && response.data.result.images.length > 0) {
      return response.data.result.images[0]; // URL gambar yang telah dihapus backgroundnya
    } else {
      throw new Error('Respons API tidak valid');
    }

  } catch (e) {
    console.error(e);
    return {
      status: false,
      error: e,
    };
  }
}