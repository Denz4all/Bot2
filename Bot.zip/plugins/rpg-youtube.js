let handler = async (m, { conn }) => {
    const command = m.text.trim().split(' ')[0].toLowerCase();
    const user = global.db.data.users[m.sender];
    let name = conn.getName(m.sender);

    // Pastikan user memiliki akun YouTube sebelum melakukan tindakan tertentu
    if (!user.youtube) {
        if (!['.buatakunyt', '.ythelp'].includes(command)) {
            return m.reply(`Kamu tidak memiliki akun YouTube. Buat akun terlebih dahulu dengan menggunakan .buatakunyt <nama_channel>`);
        }
    }

    const now = new Date().getTime();
    const cooldownTime = 3600000; // 1 jam

    switch (command) {
        case '.buatakunyt':
            if (!user.youtube) {
                const channelName = m.text.split(' ').slice(1).join(' ') || `${name} Channel`;
                user.youtube = {
                    name: name,
                    channelName: channelName,
                    subscribers: 0,
                    totalLikes: 0,
                    totalViewers: 0,
                    totalMoney: 0,
                    videos: [],
                    lastLive: 0,
                    lastUpload: 0,
                };
                m.reply(`Akun YouTube ${channelName} berhasil dibuat!`);
            } else {
                m.reply(`Kamu sudah memiliki akun YouTube dengan nama: ${user.youtube.channelName}`);
            }
            break;

        case '.withdraw':
            const withdrawAmount = parseInt(m.text.split(' ')[1]);

            if (isNaN(withdrawAmount) || withdrawAmount <= 0) {
                return m.reply('Jumlah yang ingin ditarik tidak valid.');
            }

            if (user.youtube.totalMoney >= withdrawAmount) {
                user.youtube.totalMoney -= withdrawAmount;
                global.db.data.users[m.sender].money += withdrawAmount;
                m.reply(`Berhasil menarik uang sebesar ${withdrawAmount.toLocaleString()} 💰`);
            } else {
                m.reply(`Uang Kamu Tidak Mencukupi Untuk Menarik ${withdrawAmount.toLocaleString()} 💰`);
            }
            break;

        case '.akunyt':
            if (user.youtube) {
                const profile = user.youtube;
                const subscribers = profile.subscribers.toLocaleString() || "0";
                const totalLikes = profile.totalLikes.toLocaleString() || "0";
                const totalViewers = profile.totalViewers.toLocaleString() || "0";
                const totalMoney = profile.totalMoney.toLocaleString() || "0";
                const videoCount = profile.videos.length || "0";
                const verification = profile.subscribers >= 100000 ? '✔️ Terverifikasi' : '❌ Belum Terverifikasi';

                m.reply(`
📈 Akun YouTube ${profile.name} 📉
🌐 Channel: ${profile.channelName}
👥 Subscribers: ${subscribers} 
👍🏻 Likes: ${totalLikes} 
🪬 Viewers: ${totalViewers} 
💰 Total Uang: ${totalMoney} 💰
📹 Jumlah Video: ${videoCount} 📹
${verification}
                `);
            } else {
                m.reply(`Kamu tidak memiliki akun YouTube. Buat akun terlebih dahulu dengan menggunakan .buatakunyt <nama_channel>`);
            }
            break;

        case '.live':
            if (now - user.youtube.lastLive < cooldownTime) {
                const remainingTime = cooldownTime - (now - user.youtube.lastLive);
                return m.reply(`Kamu perlu menunggu ${clockString(remainingTime)} sebelum bisa melakukan live lagi.`);
            }

            const liveTitle = m.text.split(' ').slice(1).join(' ');
            if (liveTitle) {
                const subscribers = user.youtube.subscribers;
                let incomeRange = calculateIncome(subscribers);

                let newSubscribers = Math.floor(Math.random() * 1000);
                let newViewers = Math.floor(Math.random() * 10000);
                let newLikes = Math.floor(Math.random() * 500);
                let moneyEarned = randomInt(incomeRange.min, incomeRange.max);

                user.youtube.subscribers += newSubscribers;
                user.youtube.totalViewers += newViewers;
                user.youtube.totalLikes += newLikes;
                user.youtube.totalMoney += moneyEarned;
                user.youtube.lastLive = now;

                m.reply(`
[ 🎦 ] Hasil Live Streaming
📹 Judul Live: ${liveTitle}
📈 New Subscribers: +${newSubscribers.toLocaleString()}
🪬 New Viewers: ${newViewers.toLocaleString()}
👍🏻 New Likes: ${newLikes.toLocaleString()}
💰 Uang yang didapat: ${moneyEarned.toLocaleString()} 💰
                `);
            } else {
                m.reply(`Tolong berikan judul untuk live streaming!`);
            }
            break;

        case '.upload':
            if (now - user.youtube.lastUpload < cooldownTime) {
                const remainingTime = cooldownTime - (now - user.youtube.lastUpload);
                return m.reply(`Kamu perlu menunggu ${clockString(remainingTime)} sebelum bisa mengupload video lagi.`);
            }

            const videoTitle = m.text.split(' ').slice(1).join(' ');
            if (videoTitle) {
                user.youtube.videos.push(videoTitle);

                const subscribers = user.youtube.subscribers;
                let incomeRange = calculateIncome(subscribers);

                let newSubscribers = Math.floor(Math.random() * 100);
                let newViewers = Math.floor(Math.random() * 10000);
                let newLikes = Math.floor(Math.random() * 500);
                let moneyEarned = randomInt(incomeRange.min, incomeRange.max);

                user.youtube.subscribers += newSubscribers;
                user.youtube.totalLikes += newLikes;
                user.youtube.totalViewers += newViewers;
                user.youtube.totalMoney += moneyEarned;
                user.youtube.lastUpload = now;

                m.reply(`
[ 🎦 ] Hasil Upload Video
📹 Judul Video: ${videoTitle}
📈 New Subscribers: +${newSubscribers.toLocaleString()}
🪬 New Viewers: ${newViewers.toLocaleString()}
👍🏻 New Likes: ${newLikes.toLocaleString()}
💰 Uang yang didapat: ${moneyEarned.toLocaleString()} 💰
                `);
            } else {
                m.reply(`Tolong berikan judul video yang ingin di-upload!`);
            }
            break;

        case '.ythelp':
            m.reply(`
🔍 YOUTUBE COMMANDS
1. .buatakunyt <nama_channel> - Membuat akun YouTube baru.
2. .withdraw <jumlah> - Menarik uang dari akun YouTube.
3. .akunyt - Melihat informasi akun YouTube.
4. .live <judul> - Melakukan live streaming.
5. .upload <judul> - Mengupload video.
            `);
            break;

        default:
            m.reply(`Perintah tidak dikenali. Gunakan .ythelp untuk melihat daftar perintah YouTube.`);
            break;
    }
}

// Helper Functions
function clockString(ms) {
    let h = Math.floor(ms / 3600000);
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
}

function calculateIncome(subscribers) {
    if (subscribers < 100000) return { min: 100000, max: 500000 }; // Sedikit
    if (subscribers < 1000000) return { min: 500000, max: 5000000 }; // Standar
    return { min: 5000000, max: 10000000 }; // Banyak
}

function randomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

handler.command = /^(buatakunyt|withdraw|akunyt|live|upload|ythelp)$/i;
export default handler;