/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

export async function all(m) {
  let setting = global.db.data.settings[this.user.jid];
  if (new Date() * 1 - setting.expiredCD > 600000) {
    let data = Object.entries(global.db.data.chats).filter(
      (v) => v[1].expired > 0 && new Date() * 1 - v[1].expired > 0,
    );
    for (let v of data) {
      try {
        let groupMetadata = await conn.groupMetadata(v[0]);
        this.reply(
          v[0],
          `Waktunya *${this.user.name}* Untuk Meninggalkan Group\nJangan lupa sewa lagi ya!`,
          null,
        ).then(() => {
          this.sendContact(v[0], global.config.owner, null).then(() => {
            this.groupLeave(v[0]);
            global.db.data.chats[v[0]].expired = 0;
          });
        });
      } catch (e) {
        global.db.data.chats[v[0]].expired = 0;
      }
    }
    setting.expiredCD = new Date() * 1;
  }
  return !0;
};



/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

/*export async function all(m) {
  let setting = global.db.data.settings[this.user.jid];
  if (new Date() * 1 - setting.expiredCD > 600000) {
    let gcJoinData = global.db.data.bots.gcJoin;
    let allGroups = await conn.groupFetchAllParticipating();
    let groupIds = Object.keys(allGroups);

    // Leave groups that are not in the gcJoin list with a message
    for (let id of groupIds) {
      if (!gcJoinData.some(g => g.id === id)) {
        try {
          await this.reply(
            id,
            `Waduh ${wm} tidak bisa mendapatkan info sewa group ini, mohon hubungi owner.`,
            null
          );
          await this.groupLeave(id);
          this.delay(1000)
        } catch (e) {
          console.error(`Failed to leave group ${id}:`, e);
        }
      }
    }

    // Check for expired groups in the gcJoin list
    let expiredGroups = gcJoinData.filter(
      (v) => v.expired > 0 && new Date() * 1 - v.expired > 0,
    );
    for (let v of expiredGroups) {
      try {
        let groupMetadata = await conn.groupMetadata(v.id);
        await this.reply(
          v.id,
          `Waktunya *${this.user.name}* Untuk Meninggalkan Group\nJangan lupa sewa lagi ya!`,
          null,
        );
        await this.sendContact(v.id, global.config.owner, null);
        await this.groupLeave(v.id);
        v.expired = 0;
      } catch (e) {
        v.expired = 0;
      }
    }
    setting.expiredCD = new Date() * 1;
  }
  return !0;
}*/