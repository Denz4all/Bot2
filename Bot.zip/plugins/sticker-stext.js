import axios from "axios";
import { sticker } from "../lib/sticker.js";

let handler = async (m, { conn, text }) => {
  if (!text && !m.quoted)
    return m.reply("Contoh: -SText Hasan Gay!");

  try {
    let jsonnya = {
      type: "quoted",
      format: "webp",
      backgroundColor: "black",
      width: 512,
      height: 768,
      scale: 2,
      messages: [
        {
          entities: [],
          avatar: true,
          from: {
            id: 1,
            name: m.quoted ? m.quoted.name : m.pushName,
            photo: {
              url: m.quoted
                ? await conn
                    .profilePictureUrl(m.quoted.sender, "image")
                    .catch(() => "https://telegra.ph/file/6252105fc99ea4b4b0da8.png")
                : await conn
                    .profilePictureUrl(m.sender, "image")
                    .catch(() => "https://telegra.ph/file/6252105fc99ea4b4b0da8.png"),
            },
          },
          text: m.quoted ? m.quoted.text : text,
          replyMessage: {},
        },
      ],
    };

    const post = await axios.post(
      "https://bot.lyo.su/quote/generate",
      jsonnya,
      {
        headers: { "Content-Type": "application/json" },
      }
    );

    let buff = await Buffer.from(post.data.result.image, "base64");
    if (!buff) return m.reply("Error");

    let stiker = await sticker(buff, false, "seo nari", "6287854403765");
    await conn.sendFile(m.chat, stiker, "", "", m);
  } catch (e) {
    return m.reply("Error Kak!");
  }
};

handler.help = ["Stext"];
handler.tags = ["sticker"];
handler.command = ["stext", "steks"];

export default handler;