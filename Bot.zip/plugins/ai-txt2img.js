/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

/* dibuat oleh Cifumo
owner: https://wa.me/62887437975626
bot: https://wa.me/6283151441108
ig: https://instagram.com/tyoochann
github: - */

/* dibuat oleh Cifumo
owner: https://wa.me/6283114439876
bot: https://wa.me/6283151441108
ig: https://instagram.com/tyoochann
github: - */

import axios from "axios";
import fetch from "node-fetch";
import uploadImage from "../lib/uploadImage.js";

const defaultPayloads = {
  server_name: "jisoo",
  prompt: "",
  width: 512,
  height: 768,
  steps: 20,
  model_id: "meinamix",
  sampler: "UniPC",
  seed: "",
  cfg: 4.0,
  image_num: 1,
  negative_prompt:
    "(worst quality, low quality:1.3), extra hands, extra limbs, bad anatomy",
  safety_checker: "no",
  enhance_prompt: "no",
  multi_lingual: "no",
  clip_skip: 2,
  panorama: "no",
  lora_model: "more_details",
  lora_strength: 0.5,
  embeddings_model: "",
  webhook: null,
};

const handler = async (m, { text, command, isOwner, args, usedPrefix }) => {
  // Ambil payloads pengguna dari database jika sudah tersimpan
  let userPayloads = db.data.users[m.sender]?.payloads || defaultPayloads;

  if (!text) {
    // Jika tidak ada teks, beri contoh penggunaan command
    return m.reply(
      `Example: *${usedPrefix + command}* 1girl, seductive smile, close-up.`,
    );
  }

  // Jika pengguna adalah pemilik bot
  if (isOwner) {
    if (args[0] === "set") {
      if (args.length % 2 !== 1) {
        return m.reply("Invalid arguments.");
      }

      // Simpan payloads yang diatur oleh pengguna ke dalam database
      for (let i = 1; i < args.length; i += 2) {
        const key = args[i];
        const value = args[i + 1];
        if (key && value) {
          userPayloads[key] = value;
          m.reply(`🌸 *${key}* has been set to *${value}*.`);
        }
      }
      db.data.users[m.sender].payloads = userPayloads; // Simpan perubahan payloads ke dalam database
      await db.write(); // Simpan database
      return;
    }

    if (args[0] === "showall") {
      let payloadInfo = "*Payloads*:";
      // Tampilkan semua payloads yang tersimpan
      for (const [key, value] of Object.entries(userPayloads)) {
        payloadInfo += `\n${key}: ${value}`;
      }
      return m.reply(payloadInfo);
    }
  }

  // Gunakan payloads dari pengguna jika sudah diatur sebelumnya
  const updatedPayloads = { ...userPayloads, prompt: text };

  let { key } = await conn.sendMessage(
    m.chat,
    { text: "_Preparing Stable diffusion..._" },
    { quoted: m },
  );

  // Kirim permintaan dengan payloads yang diperbarui
  const { data } = await axios
    .request({
      baseURL: "https://api.itsrose.rest",
      url: "/image/diffusion/txt2img",
      method: "POST",
      headers: {
        accept: "application/json",
        Authorization: APIKeys[APIs["rose"]],
        "Content-Type": "application/json",
      },
      data: updatedPayloads,
    })
    .catch((e) => e?.response);

  const { status, message, result } = data;

  if (!status) {
    return m.reply(message);
  }

  const { metadata, images, generation_time } = result;
  const {
    model_id,
    scheduler,
    W,
    H,
    guidance_scale,
    steps,
    seed,
    clip_skip,
    lora,
    negative_prompt,
  } = metadata;

  const medata = `*Generating Time*: ${generation_time.toFixed()} second
  *prompt*: ${text}
  *model_id*: ${model_id}
  *lora*: ${lora}
  *negative_prompt*: ${negative_prompt}
  *scheduler*: ${scheduler}
  *W*: ${W}
  *H*: ${H}
  *guidance_scale*: ${guidance_scale}
  *steps*: ${steps}
  *seed*: ${seed}
  *clip_skip*: ${clip_skip}`;

  await conn.sendMessage(m.chat, {
    text: medata,
    edit: key,
  });

  await conn.sendFile(
    m.chat,
    images[0],
    "ini.jpg",
    "Prompt: " + "```" + text + "```",
    m,
  );
};

handler.command = handler.help = ["txt2img", "aiimg", "showall"];
handler.tags = ["ai"];
handler.premium = true; handler.error = 0

export default handler;
