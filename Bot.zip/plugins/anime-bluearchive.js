/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

import { list, audio, detail } from "../lib/scraper/arsipbiru.js";
import axios from "axios";

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) {
    global.db.data.settings[conn.user.jid].loading
      ? await m.reply(global.config.loading)
      : false;
    let result = await list();
    let rows = result.map((item) => ({
      title: item.name,
      description: `${item.title}\n${item.link}`,
      id: `${usedPrefix + command} ${item.link} detail`,
    }));

    let buttonMsg = {
      title: "Click Here",
      sections: [
        {
          title: "Character List",
          rows: rows,
        },
      ],
    };

    let buttons = [
      {
        name: "single_select",
        buttonParamsJson: JSON.stringify(buttonMsg),
      },
    ];

    conn.sendButton(
      m.chat,
      "",
      "Silahkan pilih karakter yang anda cari dibawah",
      global.config.watermark,
      buttons,
      m,
    );
    return;
  }

  // Memisahkan perintah untuk "detail" dan "audio"
  const [characterName, type] = text.split(" ");

  if (command === "bluearchive" && type === "audio") {
    // Jika perintah mengandung "audio"
    global.db.data.settings[conn.user.jid].loading
      ? await m.reply(global.config.loading)
      : false;
    let result = await audio(characterName);

    let rows = result.map((item) => ({
      title: item.title,
      description: item.engTitle,
      id: `${usedPrefix}get ${item.audioLink}`,
    }));

    let buttonMsg = {
      title: "Click Here",
      sections: [
        {
          title: "Audio List",
          rows: rows,
        },
      ],
    };

    let buttons = [
      {
        name: "single_select",
        buttonParamsJson: JSON.stringify(buttonMsg),
      },
    ];

    conn.sendButton(
      m.chat,
      "",
      "Silahkan pilih audio yang anda cari dibawah",
      global.config.watermark,
      buttons,
      m,
    );
  } else if (command === "bluearchive" && type === "detail") {
    // Jika perintah hanya mengandung "detail"
    global.db.data.settings[conn.user.jid].loading
      ? await m.reply(global.config.loading)
      : false;
    let result = await detail(characterName);
    let teks = `
Title: ${result.title || "none"}
Age: ${result.biodata.Age || "none"}
Birthday: ${result.biodata.Birthday}
Height: ${result.biodata.Height}
School Year: ${result.biodata["School Year"]}
Club: ${result.biodata.Club}
Hobby: ${result.biodata.Hobby}
Obtainability: ${result.biodata.Obtainability}
Voice Actor: ${result.biodata["Voice Actor"]}
Illustrator: ${result.biodata.Illustrator}
`.trim();

    

    conn.sendImgButton(
      m.chat,
      result.icons.getRandom().url,
      "",
      teks,
      global.config.watermark,
      [['Audio', `${usedPrefix + command} ${result.audio} audio`]],
      m,
    );
  } else {
    await m.reply(`Invalid command. Use ${usedPrefix}${command} [character_name] detail or ${usedPrefix}${command} [character_name] audio`);
  }
};

handler.help = ["bluearchive"];
handler.tags = ["anime"];
handler.command = /^(bluearchive)$/i;
handler.limit = true;
handler.error = 0;
export default handler;

async function originalUrl(url) {
  return (await axios(url)).request.res.responseUrl;
}

const delay = (time) => new Promise((res) => setTimeout(res, time));