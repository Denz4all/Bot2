/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

import axios from "axios";

const handler = async (m, { conn, text, command, usedPrefix }) => {
  if (!text) {
    return m.reply(`Ketik apa yang ingin Anda cari.\n*Contoh*: ${usedPrefix + command} Minecraft`);
  }

  // Bagian Pertama: Jika Input Berupa URL
  if (/html/i.test(text)) {
    let { data } = await axios.get(`https://api.neoxr.eu/api/an1-get?url=${text}`);
    if (!data.status) return m.reply("Terjadi kesalahan saat mengambil data, coba lagi nanti.");

    let {
      name,
      requirement,
      version,
      size,
      description,
      rating,
      published,
      installed,
      url,
    } = data.data;

    let caption = `*[ Downloader An1 ]*

🔹 *Nama*: ${name}
🔹 *Versi*: ${version}
🔹 *Ukuran*: ${size}
🔹 *Rating*: ${rating} ⭐️
🔹 *Diterbitkan*: ${published}
🔹 *Jumlah Install*: ${installed}

📝 *Deskripsi*: 
${description}

➡️ *Link Download*: [Klik disini](${url})

_Pastikan Anda menunggu beberapa saat untuk pengunduhan file._`;

    await conn.sendThumb(
      m.chat,
      caption,
      "https://files.catbox.moe/epu529.png",
      m,
    );
    await conn.sendFile(m.chat, url, name, "Download selesai", m, { mimetype: 'application/vnd.android.package-archive'});
  } else {
    let { data } = await axios.get(`https://api.neoxr.eu/api/an1?q=${text}`);
    if (!data.data || data.data.length === 0) {
      return m.reply("Tidak ada hasil yang ditemukan untuk pencarian Anda.");
    }

    let listCaption = `*[ Android1 Downloader ]*\n\n*Hasil pencarian untuk*: _${text}_\n`;

    let buttons = data.data.map((v, i) => ({
      alias: i + 1,
      response: `${usedPrefix + command} ${v.url}`
    }));

    data.data.forEach((v, i) => {
      listCaption += `\n${i + 1}. *${v.name}*\n   ➡️ Developer: ${v.developer}\n   ⭐️ Rating: ${v.rating}\n`;
    });

    listCaption += `\n\nPilih nomor untuk melihat lebih lanjut atau unduh aplikasi yang Anda inginkan.`;

    await conn.sendAliasMessage(
      m.chat,
      { text: listCaption },
      buttons,
      m,
    );
  }
};

handler.command = ["an1", "android1", "androit1"];
handler.help = ["android1"];
handler.tags = ["downloader", "internet", "tools"];
handler.limit = true;
handler.error = 0;
handler.register = true;

export default handler;