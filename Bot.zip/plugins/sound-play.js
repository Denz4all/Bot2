
/*
wa.me/6287815194609
github: https://github.com/cifumo
Instagram: https://instagram.com/tyoochann
Ini watermark gw cok jangan dihapus
*/
import { youtube } from '@xct007/frieren-scraper';
import axios from 'axios';
import yt from '../lib/scraper/yt.js';

let handler = async (m, { conn, args, usedPrefix, command }) => {
  conn.room = conn.room || {};
  const query = args.slice(1).join(' ') || '';
  
  if (!query) {
    return m.reply(`Masukan Query!\n\nContoh:\n${usedPrefix + command} audio Grand Escape\n${usedPrefix + command} video Grand Escape Amv`);
  }

  if (!/audio|video/i.test(args[0])) {
    return m.reply(`Masukan Query!\n\nContoh:\n${usedPrefix + command} audio Grand Escape\n${usedPrefix + command} video Grand Escape Amv`);
  }

  const id = 'youtube_' + m.sender;

  try {
    conn.room[id] = true;

    const searchResults = await youtube.search(query);
    if (!searchResults || searchResults.length === 0) {
      return m.reply('Tidak ada hasil yang ditemukan untuk query tersebut.');
    }

    const { title, uploaded, duration, views, url, thumbnail } = searchResults[0];
    const caption = `
🎧 Title: ${title}
📤 Published: ${uploaded}
⏰ Duration: ${duration}
👁️ Views: ${views}

🔗 Url: ${url}
`.trim();

    const msg = await conn.adReply(m.chat, caption, title, 'Playing 🔊', thumbnail, url, m);

    if (/play/i.test(command)) {
      switch (args[0].toLowerCase()) {
        case 'audio':
          await handleAudio(conn, m, msg, url);
          break;

        case 'video':
          await handleVideo(conn, m, msg, url);
          break;

        default:
          return m.reply('Jenis file tidak dikenali. Gunakan "audio" atau "video".');
      }
    }
  } catch (e) {
    console.error(e);
    return m.reply(`Terjadi kesalahan: ${e.message}`);
  } finally {
    delete conn.room[id];
  }
};

async function handleAudio(conn, m, msg, url) {
  try {
    const dl = await yt.mp3(url);
    const title = dl.title || 'N/A';
    const fileSizeInBytes = Buffer.byteLength(dl.media);
    const fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
    const thumbnailUrl = dl.metadata.thumbnail;

    if (fileSizeInMegabytes > 60) {
      const jpegThumbnail = await conn.resize(thumbnailUrl, 400, 400);
      await conn.sendMessage(
        m.chat,
        {
          document: dl.media,
          mimetype: 'audio/mpeg',
          fileName: `${title}.mp3`,
          jpegThumbnail,
          fileLength: fileSizeInBytes,
        },
        { quoted: msg }
      );
    } else {
      await conn.sendMessage(
        m.chat,
        {
          audio: dl.media,
          fileName: `${title}.mp3`,
          mimetype: 'audio/mpeg',
        },
        { quoted: msg }
      );
    }
  } catch (e) {
    throw new Error(`Gagal mengunduh audio: ${e.message}`);
  }
}

async function handleVideo(conn, m, msg, url) {
  try {
    const dl = await yt.mp4(url);
    const title = dl.title || 'N/A';
    const fileSizeInBytes = Buffer.byteLength(dl.media);
    const fileSizeInMegabytes = fileSizeInBytes / (1024 * 1024);
    const thumbnailUrl = dl.metadata.thumbnail;
    const jpegThumbnail = await conn.resize(thumbnailUrl, 400, 400);

    if (fileSizeInMegabytes > 100) {
      await conn.sendMessage(
        m.chat,
        {
          document: dl.media,
          mimetype: 'video/mp4',
          fileName: `${title}.mp4`,
          jpegThumbnail,
          fileLength: fileSizeInBytes,
        },
        { quoted: msg }
      );
    } else {
      await conn.sendMessage(
        m.chat,
        {
          video: dl.media,
          fileName: `${title}.mp4`,
          mimetype: 'video/mp4',
        },
        { quoted: msg }
      );
    }
  } catch (e) {
    throw new Error(`Gagal mengunduh video: ${e.message}`);
  }
}

handler.help = ['play'].map((v) => v + ' <type> <query>');
handler.tags = ['sound'];
handler.command = /^play$/i;
handler.limit = true;

export default handler;