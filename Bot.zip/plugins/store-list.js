/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

let handler = async (m, { conn, usedPrefix, command }) => {
  let store = global.db.data.chats[m.chat].store;

  let setting = global.db.data.settings[conn.user.jid];
  let list = Object.values(store);
  if (list.length == 0) return m.reply("Belum ada list di group ini");
  let rows = [];
  for (let i = 0; i < list.length; i++) {
    let result = {
      header: "",
      title: list[i].command,
      description: "",
      id: list[i].command,
    };
    rows.push(result);
  }
  let buttonMsg = {
    title: "Click Here",
    sections: [
      {
        title: "List Yang Ada Di Group Ini",
        highlight_label: "Popular",
        rows: rows,
      },
    ],
  };
  let buttons = [
    {
      name: "single_select",
      buttonParamsJson: JSON.stringify(buttonMsg),
    },
  ];
  conn.sendButton(
    m.chat,
    "",
    "Berikut list command yang ada digroup ini",
    global.config.watermark,
    buttons,
    m,
  );
};
handler.help = ["list"];
handler.tags = ["store"];
handler.command = /^(list(store)?)$/i;
handler.group = true;
export default handler;
