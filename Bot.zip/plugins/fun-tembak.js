/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

let handler = async (m, { conn, usedPrefix, command, text }) => {
  let who = m.mentionedJid[0]
    ? m.mentionedJid[0]
    : m.quoted
      ? m.quoted.sender
      : text
        ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
        : false;
  if (!who)
    return m.reply(
      `Reply atau tag orangnya! \n\nContoh : \n${usedPrefix + command} @${m.sender.split("@")[0]}`,
      false,
      { mentions: [m.sender] }
    );

  // Cek apakah nomor yang dituju adalah nomor bot
  if (who == conn.user.jid) {
    return m.reply("Aku sepenuhnya milik owner");
  }

  // Cek apakah nomor yang dituju adalah nomor pemilik
  if (who == global.info.nomorown + "@s.whatsapp.net") {
    return m.reply("Lu siapa?? Ini pacar Aryaa tau ><");
  }

  let user = global.db.data.users;
  if (typeof user[who] == "undefined")
    return m.reply("Orang ini gak ada di database");
  if (user[who].pacar == m.sender)
    return m.reply("Orang ini udah jadi pacar kamu");
  if (user[who].pacar != "") return m.reply("Orang ini udah punya pacar");
  if (user[who].tembak == m.sender)
    return m.reply(
      "Kamu sudah menembak orang ini, silahkan tunggu jawaban darinya!"
    );
  if (user[who].tembak != "")
    return m.reply("Orang ini sudah ditembak!", false, {
      mentions: [user[who].tembak],
    });
  if (user[m.sender].pacar != "")
    return m.reply("Kamu udah punya pacar! Jangan selingkuh goblok!");
  if (user[m.sender].tembak != "")
    return m.reply(
      `Lu udah nembak @${user[who].tembak.split("@")[0]}, jangan nembak orang lain!`,
      false,
      { mentions: [user[m.sender].tembak] }
    );
  if (who == m.sender) return m.reply("Napa nembak diri sendiri kak? Ciee kesepian ya? :v");

  user[who].tembak = m.sender;
  user[m.sender].tembak = who;

  await m.reply(
    `Kamu sudah menembak @${who.split("@")[0]} untuk menjadi pacar kamu! Silahkan tunggu jawaban darinya... \n\nKetik: \n${usedPrefix}terima - Untuk menerima \n${usedPrefix}tolak - Untuk menolak`,
    false,
    { mentions: [who] }
  );
};

handler.help = ["tembak"];
handler.tags = ["fun"];
handler.command = /^(tembak|dor)$/i;
handler.group = true;
export default handler;