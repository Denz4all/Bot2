let handler = async (m, { conn, command, text }) => {
conn.reply(m.chat, `Sok Asik Banget Lu Memek
`.trim(), m)
}
handler.customPrefix = /^(botkontol|bot kontol|botasu|bot asu|botsters|bot gila|botnyagoblok|bot nya goblok|bot goblok|bot sters|bot kentang|gilabotnya|hadeh bot kontol|bot ngentod|botngentod)$/i 
handler.command = new RegExp

export default handler