const handler = async (m, { conn, usedPrefix }) => {
  // Data gabungan libur nasional dan hari penting nasional
  const events = [
    { date: '2024-01-01', name: 'Tahun Baru Masehi', description: 'Libur Tahun Baru', type: 'Libur Nasional' },
    { date: '2024-01-03', name: 'Hari Departemen Agama', description: 'Hari Peringatan Departemen Agama', type: 'Hari Penting Nasional' },
    { date: '2024-02-09', name: 'Hari Pers Nasional', description: 'Peringatan Hari Pers Nasional', type: 'Hari Penting Nasional' },
    { date: '2024-02-10', name: 'Tahun Baru Imlek', description: 'Perayaan Imlek', type: 'Libur Nasional' },
    { date: '2024-03-11', name: 'Hari Raya Nyepi', description: 'Perayaan Nyepi Umat Hindu', type: 'Libur Nasional' },
    { date: '2024-04-10', name: 'Hari Raya Idul Fitri', description: 'Lebaran Hari Pertama', type: 'Libur Nasional' },
    { date: '2024-04-11', name: 'Hari Raya Idul Fitri', description: 'Lebaran Hari Kedua', type: 'Libur Nasional' },
    { date: '2024-04-21', name: 'Hari Kartini', description: 'Memperingati Jasa Pahlawan Nasional RA Kartini', type: 'Hari Penting Nasional' },
    { date: '2024-05-01', name: 'Hari Buruh Internasional', description: 'Peringatan Hari Buruh Internasional', type: 'Libur Nasional' },
    { date: '2024-05-02', name: 'Hari Pendidikan Nasional', description: 'Peringatan Hari Pendidikan Nasional', type: 'Hari Penting Nasional' },
    { date: '2024-06-01', name: 'Hari Lahir Pancasila', description: 'Memperingati Lahirnya Pancasila', type: 'Libur Nasional' },
    { date: '2024-06-17', name: 'Hari Raya Idul Adha', description: 'Perayaan Idul Adha', type: 'Libur Nasional' },
    { date: '2024-08-17', name: 'Hari Kemerdekaan RI', description: 'Peringatan Kemerdekaan Republik Indonesia', type: 'Libur Nasional' },
    { date: '2024-10-02', name: 'Hari Batik Nasional', description: 'Peringatan Hari Batik sebagai Warisan Budaya Dunia', type: 'Hari Penting Nasional' },
    { date: '2024-10-28', name: 'Hari Sumpah Pemuda', description: 'Peringatan Sumpah Pemuda', type: 'Hari Penting Nasional' },
    { date: '2024-11-10', name: 'Hari Pahlawan', description: 'Memperingati Jasa Para Pahlawan Indonesia', type: 'Hari Penting Nasional' },
    { date: '2024-12-25', name: 'Hari Raya Natal', description: 'Perayaan Hari Natal', type: 'Libur Nasional' },
  ];

  // Sortir daftar berdasarkan tanggal
  events.sort((a, b) => new Date(a.date) - new Date(b.date));

  // Header pesan
  let message = `🎉 *Daftar Tanggal Merah dan Hari Penting Nasional 2024*\n\n`;

  message += `┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  message += `┃ 📅 *Tanggal*     | 📜 *Nama Peringatan*\n`;
  message += `┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

  // Looping untuk menampilkan daftar hari libur dan peringatan nasional
  events.forEach(event => {
    // Format tanggal agar lebih enak dilihat
    let formattedDate = new Date(event.date).toLocaleDateString('id-ID', { 
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' 
    });

    // Menampilkan hari libur dan hari penting dengan ikon berbeda
    message += `┃ 🗓 *${formattedDate}*\n`;
    message += `┃ 📛 *${event.name}*\n`;
    message += `┃ 🔎 *Tipe*: ${event.type}\n`;
    message += `┃ 🔎 *Alasan*: ${event.description}\n`;
    message += `┣━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
  });

  message += `┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

  // Kirim pesan daftar tanggal merah dan hari penting kepada pengguna
  conn.reply(m.chat, message, m);
};

// Metadata handler
handler.command = /^(liburnasional|tanggalmerah|haripenting)$/i;  // Ubah perintah menjadi 'hariliburnasional'
handler.tags = ['info'];
handler.help = ['liburnasional'];  // Ubah bantuan menjadi 'hariliburnasional'
handler.premium = false;  // Semua pengguna bisa mengakses
handler.register = true;  // Pengguna harus terdaftar di database

export default handler;