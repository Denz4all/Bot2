/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

/* dibuat oleh Cifumo
owner: https://wa.me/6283114439876
bot: https://wa.me/6283151441108
ig: https://instagram.com/tyoochann
github: - */

import Anthropic from "@anthropic-ai/sdk";
import upload from "../lib/uploadImage.js";

const anthropic = new Anthropic({
  apiKey: "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",
});

const handler = async (m, { conn, text }) => {
  if (!text && !(m.quoted && m.quoted.mimetype.includes("image"))) {
    m.reply("Mohon reply pesan dengan gambar atau ketik teks untuk menghasilkan pesan.");
    return;
  }

  // Inisialisasi sesi percakapan untuk pengguna, mirip dengan OpenAI
  conn.anthropic = conn.anthropic || {};

  // Buat sesi baru jika pengguna belum memiliki sesi
  if (!(m.sender in conn.anthropic)) {
    conn.anthropic[m.sender] = {
      timeOut: setTimeout(() => delete conn.anthropic[m.sender], 600000), // Bersihkan sesi setelah 10 menit
      messages: [],
    };
  } else {
    clearTimeout(conn.anthropic[m.sender].timeOut); // Reset waktu sesi
  }

  let response;

  try {
    if (m.quoted && m.quoted.mimetype.includes("image")) {
      // Jika pengguna merespon dengan gambar, proses gambar dan tambahkan ke sesi
      const mediaData = await m.quoted.download();
      const up = await upload(mediaData);
      const base64Data = Buffer.from(up, "binary").toString("base64");

      response = await anthropic.messages.create({
        model: "claude-3-opus-20240229",
        max_tokens: 4000,
        temperature: 1,
        system: 'gunakan hanya bahasa Indonesia. Berperanlah sebagai karakter yang ramah, bersemangat, dan menyesuaikan diri dengan cara bicara pengguna.',
        messages: [
          ...conn.anthropic[m.sender].messages,
          {
            role: "user",
            content: [
              { type: "text", text: text || "" },
              { type: "image", source: { type: "base64", media_type: m.quoted.mimetype, data: base64Data } },
            ],
          },
        ],
      });
    } else {
      // Jika pengguna hanya merespon dengan teks, tambahkan teks ke sesi
      response = await anthropic.messages.create({
        model: "claude-3-opus-20240229",
        max_tokens: 4000,
        temperature: 1,
        system: 'gunakan hanya bahasa Indonesia. Berperanlah sebagai karakter yang ramah, bersemangat, dan menyesuaikan diri dengan cara bicara pengguna.',
        messages: [
          ...conn.anthropic[m.sender].messages,
          {
            role: "user",
            content: [{ type: "text", text: text || "" }],
          },
        ],
      });
    }

    // Simpan percakapan pengguna dan respons asisten dalam sesi
    conn.anthropic[m.sender].messages.push(
      { role: "user", content: text },
      { role: "assistant", content: response.content[0].text }
    );

    m.reply(response.content[0].text);
  } catch (error) {
    m.reply(error.message);
  }

  // Set timeout untuk menghapus sesi setelah 10 menit tanpa aktivitas
  conn.anthropic[m.sender].timeOut = setTimeout(() => {
    delete conn.anthropic[m.sender];
  }, 600000);
};

handler.command = ["claude"];
handler.help = ["claude <teks/replyImage>"];
handler.tags = ["ai", "premium"];
handler.onlyprem = true;
handler.limit = true;

export default handler;