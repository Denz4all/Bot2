const handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, 'Silakan masukkan detail fitur yang ingin dibuat atau yang error.', m);

  const message = `*[REQUEST FITUR]*\n\nPengguna: @${m.sender.replace(/@.+/g, '')}\n\nFitur yang diminta: ${text}`;

  // Mengirimkan request fitur ke admin atau grup tertentu
  const adminJid = '6287815194609@s.whatsapp.net'; // Ganti dengan JID admin atau grup
  await conn.sendMessage(adminJid, { text: message, mentions: [m.sender] });

  // Konfirmasi kepada pengguna bahwa request sudah dikirim
  conn.reply(m.chat, '_Pesan terkirim kepemilik bot, jika reqfitur hanya main-main tidak akan ditanggapi._', m);
};

handler.help = ['reqfitur <nama fitur>'];
handler.tags = ['main'];
handler.command = /^(reqfitur|requestfitur)$/i;
handler.private = false; // Menjadikan command ini bisa digunakan secara publik

export default handler;