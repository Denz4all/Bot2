var handler = async (m, { text }) => {
    let user = global.db.data.users[m.sender]
    user.afk = +new Date()
    user.afkReason = text || null // Set to null if no reason is provided
    m.reply(`${conn.getName(m.sender)} AFK${text ? ' Dengan Alasan: ' + text : ' tanpa alasan'}`)
}

handler.help = ['afk']
handler.tags = ['main']
handler.command = /^afk|aefka|offsek$/i

export default handler