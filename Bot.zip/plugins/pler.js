/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

import {
  generateWAMessageFromContent,
  prepareWAMessageMedia,
} from "@adiwajshing/baileys";

let handler = async (m, { conn }) => {
  let tese = "tese";
  let msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            body: {
              text: "test",
            },
            footer: {
              text: "test",
            },
            header: {
              title: "test",
              subtitle: "test",
              hasMediaAttachment: false,
              ...(await prepareWAMessageMedia(
                { image: { url: global.thumb } },
                { upload: conn.waUploadToServer },
              )),
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson:
                    '{"title":"tess","sections":[{"title":"anu","highlight_label":"label","rows":[{"header":"ehek","title":".owner","description":"apa aja dah","id":".owner"},{"header":"header","title":"title","description":"description","id":".owner"}]},{"title":"anu","highlight_label":"label","rows":[{"header":"ehek","title":".owner","description":"apa aja dah","id":".owner"},{"header":"header","title":"title","description":"description","id":".owner"}]}]}',
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: '{"display_text":"apalah","id":".ping"}',
                },
                {
                  name: "cta_url",
                  buttonParamsJson:
                    '{"display_text":"Ig","url":"https://instagram.com/tyoochann","merchant_url":"https://instagram.com/tyoochann"}',
                },
                {
                  name: "cta_call",
                  buttonParamsJson: '{"display_text":"call","id":"message"}',
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: `{\"display_text\":\"copy\",\"id\":\"FgIh\",\"copy_code\":\"${tese}\"}`,
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: `{\"display_text\":\"copy2\",\"id\":\".d\",\"copy_code\":\".d\"}`,
                },
                {
                  name: "cta_reminder",
                  buttonParamsJson:
                    '{"display_text":"cta_reminder","id":"message"}',
                },
                {
                  name: "cta_cancel_reminder",
                  buttonParamsJson:
                    '{"display_text":"cta_cancel_reminder","id":"message"}',
                },
                {
                  name: "address_message",
                  buttonParamsJson:
                    '{"display_text":"address_message","id":".menu"}',
                },
                {
                  name: "send_location",
                  buttonParamsJson: "",
                },
              ],
            },
            contextInfo: {
              forwardingScore: 9999,
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: global.db.data.bots.link.chid,
                serverMessageId: null,
                newsletterName: `⌜ ${global.infoo.wm} ⌟ © ${infoo.ownername || global.info.namaowner}`,
              },
              externalAdReply: {
                title: wm,
                body: infoo.wm || wm,
                thumbnailUrl:
                  "https://telegra.ph/file/8f4b696f7ba1c64b0ce2b.jpg",
                sourceUrl: global.db.data.bots.link.ig,
                mediaType: 1,
                renderLargerThumbnail: false,
              },
            },
          },
        },
      },
    },
    { quoted: m },
    {},
  );

  await conn.relayMessage(m.chat, msg, {});
};

handler.command = /^pler$/i;
export default handler;
