let handler = async (m, { conn, command, text, isOwner }) => {
    // Inisialisasi map untuk melacak penggunaan per pengguna
    if (!global.userCallCount) global.userCallCount = {};
    const userId = m.sender;

    // Tingkatkan hitungan pemanggilan pengguna
    global.userCallCount[userId] = (global.userCallCount[userId] || 0) + 1;

    // Pesan untuk spam
    const spamResponses = [
        "apasi manggil-manggil cape kontol!",
        "udah kontol cape gw",
        "gw cape anjing",
        "gausah sok asik anjing",
        "memek lu ngentod cape gw kontol"
    ];

    // Pesan biasa
    const ownerResponses = [
        "apaaa sayanggg",
        "haloo sayang",
        "ngewe yuu",
        "mauu ngewe?",
        "udah makan belum?",
        "makan dulu gihh",
        "apa owner?",
        "apaan kak?",
        "halooo ownerkuu sayang",
        "aloo sayang",
        "aloo owner",
        "apaa owner kok manggil-manggil aku?",
        "kenapa manggil owner?",
        "kamu manggil aku kah sayang?"
    ];

    const generalResponses = [
        "apasii kontol",
        "apa kontol",
        "apa kak?",
        "ada apa sayang?",
        "kenapa manggil ajg!",
        "diamlah kao babi",
        "apa cuki",
        "apa apaan manggil-manggil",
        "apasih",
        "mau ngajak ngewe kah? idih idih",
        "malas menanggapi:v",
        "pergi kau",
        "apaan sii",
        "mau apa lu?",
        "hush pergi sana!",
        "bodoamatlah",
        "wlee ga peduli 😜"
    ];

    const premiumResponses = [
        "apa kak manggil aku?",
        "kenapa coba manggil?",
        "haloo kakakk",
        "haloo kak",
        "makan dlu gih kak",
        "apa kak?",
        "kenapa hayooo manggil akuuu?",
        "adaa yang mau dibantu kah kak??",
        "ada apaaaa",
        "kenapaaa",
        "apaaaa",
        "mau main kak?",
        "mandiin aku dong kak",
        "mau mandi bareng kah?",
        "mau makan bareng kah?",
        "mandi bareng yuk kak",
        "makan bareng yuk kak",
        "tidur bareng yuk kak",
        "jangan lupa makan kak!",
        "jangan lupa sarapan kak!",
        "jangan lupa jaga kesehatannya kak!",
        "jangan galauu ya kak!",
        "eummm,jangan apa-apain aku ya kak...",
       "mauu mainn sama akuu gaa kak?",
       "jajan yu kak",
       "mau pelukan gaa kak?",
       " jangan ewe akuu yaa kak,aku masii kecilll",
    ];

    // Ambil data premium dari database
    const isPremium = global.db.data.users[userId]?.premiumTime > Date.now();

    // Pilih respon
    let response;
    if (global.userCallCount[userId] > 3) {
        response = spamResponses[Math.floor(Math.random() * spamResponses.length)];
    } else {
        if (isOwner) {
            response = ownerResponses[Math.floor(Math.random() * ownerResponses.length)];
        } else if (isPremium) {
            response = premiumResponses[Math.floor(Math.random() * premiumResponses.length)];
        } else {
            response = generalResponses[Math.floor(Math.random() * generalResponses.length)];
        }
    }

    conn.reply(m.chat, response, m);

    // Reset hitungan setelah 10 detik
    setTimeout(() => {
        global.userCallCount[userId] = 0;
    }, 10000);
};

handler.customPrefix = /^(seo|seoo|seooo|halo seo|seoo nariii|nariii|seoooo|bot|bot?|bott|seo nari|narii|seoo|sayang|dek|adek|de|byy|halo adek|haloo adek|dedek|ayang|woi seo nari|woii bot|woi bot|p bot|halo bot|hei bot|hi bot|hy|hi|hello|halo|hayy|hay|halo bot|hello bot|hy bot|hay bot|hoi bot|oi|oi bot|oiii|woiiiiii|woi bott|woi bot anj|woi bot ajg|woi bot kontol|woi bot ngentod|woi dek|halo dek|halo sayang|nari|narii|helo nari|hai nari|hai narii|halo narii|seoo narii)$/i;
handler.command = new RegExp;

export default handler;