/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

/* dibuat oleh Cifumo
owner: https://wa.me/6283114439876
bot: https://wa.me/6283151441108
ig: https://instagram.com/tyoochann
github: - */

import axios from "axios";
import { search } from '../lib/scraper/cai.js';

const handler = async (m, { conn, text }) => {
  try {
    /*const response = await axios.get(
      `${APIs['maelyn']}/api/cai/search?q=${text}&apikey=${APIKeys[APIs['maelyn']]}`,
    );*/
    const response = await search(text);

    const characters = response.result;
    global.db.data.users[m.sender].cai = { characters };

    const baten = characters.map((character, index) => [
      `${index + 1}. ${character.participant__name}`,
      character.title,
      character.external_id,
      '.caiset ' + `${index + 1}`
    ]);

    await conn.sendImgList(
      m.chat,
      'https://characterai.io/i/80/static/avatars/' + characters[0].avatar_file_name,
      '[ C a i  S e a r c h ]',
      'Silakan pilih pada menu berikut ini',
      wm,
      'Klik disini untuk memilih karakter',
      `Total karakter: ${characters.length}`,
      baten,
      m
    );

    // Set timeout 60 detik untuk menghapus sesi pencarian jika tidak ada pemilihan karakter
    setTimeout(() => {
      if (!global.db.data.users[m.sender]?.cai?.character_id) {
        delete global.db.data.users[m.sender]?.cai;
        conn.reply(
          m.chat,
          "Timeout! Sesi pencarian telah dihapus karena tidak ada pemilihan karakter.",
          m
        );
      }
    }, 60000);
  } catch (error) {
    const errorMessage = error.response ?
      error.response.data.message :
      "An error occurred.";
    conn.sendMessage(m.chat, { text: errorMessage }, { quoted: m });
  }
};

handler.command = ["caisearch"];
handler.tags = ["ai", "premium"];
handler.help = ["caisearch"];
handler.limit = true;
handler.error = 0;
handler.onlyprem = false;

export default handler;