/*
 * @Author: Cifumo
 * @Web: https://rest.cifumo.biz.id
 */

import { areJidsSameUser } from "@adiwajshing/baileys";

let handler = async (m, { conn, participants }) => {
  let user;

  // Cek apakah ada tag atau balasan pesan
  if (m.mentionedJid.length) {
    user = m.mentionedJid.find((u) => !areJidsSameUser(u, conn.user.id));
  } else if (m.quoted) {
    user = m.quoted.sender;
  }

  if (!user) return m.reply("Tag orang atau reply pesan orang yang mau di-demote!");

  // Pastikan user ada dalam grup
  const isMember = participants.some((p) => p.id === user);
  if (!isMember) return m.reply("Orang yang ditarget tidak ada dalam grup!");

  // Lakukan demote
  try {
    await conn.groupParticipantsUpdate(m.chat, [user], "demote");
    m.reply(`Berhasil mendemote admin: @${user.split("@")[0]}`, null, {
      mentions: [user],
    });
  } catch (err) {
    m.reply("Gagal mendemote admin. Pastikan bot adalah admin.");
  }
};

handler.help = ["demote"];
handler.tags = ["group"];
handler.command = /^(demote)$/i;

handler.admin = true;
handler.group = true;
handler.botAdmin = true;

export default handler;