const handler = async (m, { conn, text }) => {
  if (!text && !m.quoted) return m.reply("Masukkan teks atau reply media dengan teks");

  const chid = db.data.bots.link.chid || null;
  if (!chid) return m.reply("chid belum diatur");

  let messageOptions = {};

  // Fungsi untuk mendapatkan ekstensi dari mimetype
  const getExtension = (mimetype) => {
    const map = {
      'application/vnd.android.package-archive': '.apk',
      'application/pdf': '.pdf',
      'application/zip': '.zip',
      'application/msword': '.doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
      'application/vnd.ms-excel': '.xls',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
      'application/vnd.ms-powerpoint': '.ppt',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': '.pptx',
      'text/plain': '.txt',
      'image/jpeg': '.jpg',
      'image/png': '.png',
      'video/mp4': '.mp4',
      'audio/mpeg': '.mp3',
      'audio/ogg': '.ogg',
    };
    return map[mimetype] || ''; // Jika mimetype tidak ditemukan, gunakan string kosong
  };

  if (m.quoted && m.quoted.mimetype) {
    let mime = m.quoted.mimetype;
    let buffer = await m.quoted.download();
    let extension = getExtension(mime); // Ambil ekstensi dari mimetype
    let fileName = text ? `${text}${extension}` : `file-${new Date().getTime()}${extension}`;

    if (/image/.test(mime)) {
      messageOptions = {
        image: buffer,
        caption: text || m.quoted.text || ""
      };
    } else if (/video/.test(mime)) {
      messageOptions = {
        video: buffer,
        caption: text || m.quoted.text || "",
        mimetype: mime
      };
    } else if (/audio/.test(mime)) {
      messageOptions = {
        audio: buffer
      };
    } else if (/sticker/.test(mime)) {
      messageOptions = {
        sticker: buffer
      };
    } else {
      // Kirim sebagai dokumen dengan ekstensi yang sesuai
      messageOptions = {
        document: buffer,
        mimetype: mime,
        fileName
      };
    }
  } else {
    messageOptions = { text: text };
  }

  try {
    await conn.sendMessage(chid, messageOptions);
    m.reply("Pesan berhasil dikirim");
  } catch (error) {
    m.reply(`Gagal mengirim pesan: ${error.message}`);
  }
};

handler.command = handler.help = ['upch'];
handler.tags = ['owner'];
handler.owner = true;
export default handler;