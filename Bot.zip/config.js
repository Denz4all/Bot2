import { watchFile, unwatchFile } from "fs";
import fs from 'fs';
import chalk from "chalk";
import { fileURLToPath } from "url";

global.config = {
  /*============== INFO LINK ==============*/
  instagram: "https://instagram.com/Itzmeesukaayam",
  github: "https://github.com/Denz4all",
  group: "https://chat.whatsapp.com/CpMCB2BU5lqCurBmSzd0pU",
  website: "https://linktr.ee",

  /*============== PAYMENT ==============*/
  dana: "087815194609",
  ovo: "087815194609",
  gopay: "087815194609",
  pulsa: "087815194609",

  /*============== STAFF ==============*/
  owner: [["6287815194609", "Itzmee", true]],

  /*============= PAIRING =============*/
  pairingNumber: "6287854403765",
  pairingAuth: true,

  /*============== API ==============*/
  APIs: {
    xteam: "https://api.xteam.xyz",
    lol: "https://api.lolhuman.xyz",
    males: "https://malesin.xyz",
    zein: "https://api.zahwazein.xyz",
    rose: "https://api.itsrose.rest",
    xzn: "https://skizo.tech",
    saipul: "https://saipulanuar.cf",
    clayza: "https://api.maelyn.tech",
  },

  APIKeys: {
    "https://api.zahwazein.xyz": "zenzkey_8bb60993ae",
    "https://api.xteam.xyz": "cristian9407",
    "https://api.lolhuman.xyz": "RyAPI",
    "https://api.itsrose.life": "cDNWfULJNfbrmt6dlSDOW01XX64HsTAiMPkA63II7u4SYIum5d0KSzywHRmfTiHl",
    "https://skizo.tech": "RyHar",
    "https://api.maelyn.tech": "Rk-Ruka",
  },

  /*============== TEXT ==============*/
  watermark: "Seo nari - (Beta)",
  author: "Itzmee",
  loading: "_Chotto matte kudasai ninchan/nechann..._",
  errorMsg: "_Terjadi Error! Silahkan Coba Lagi Nanti..._",

  stickpack: "Made With",
  stickauth: "Seo nari-Bot",
  msg: {
    owner: '*ᴏᴡɴᴇʀ ᴏɴʟʏ •* ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴏᴡɴᴇʀ ʙᴏᴛ !!',
    mods: '*ᴅᴇᴠᴇʟᴏᴘᴇʀ ᴏɴʟʏ •* ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴅᴇᴠᴇʟᴏᴘᴇʀ ʙᴏᴛ !!',
    premium: '*ᴘʀᴇᴍɪᴜᴍ ᴏɴʟʏ •* ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴍᴇᴍʙᴇʀ ᴘʀᴇᴍɪᴜᴍ !!',
    group: '*ɢʀᴏᴜᴘ ᴏɴʟʏ •* ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ ʜᴀɴʏᴀ ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ɢʀᴏᴜᴘ !!',
    private: '*ᴘʀɪᴠᴀᴛᴇ ᴏɴʟʏ •* ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ ʜᴀɴʏᴀ ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴄʜᴀᴛ ᴘʀɪʙᴀᴅɪ !!',
    admin: '*ᴀᴅᴍɪɴ ᴏɴʟʏ •* ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ ʜᴀɴʏᴀ ᴜɴᴛᴜᴋ ᴀᴅᴍɪɴ ɢʀᴏᴜᴘ !!',
    botAdmin: 'ᴊᴀᴅɪᴋᴀɴ ʙᴏᴛ ꜱᴇʙᴀɢᴀɪ ᴀᴅᴍɪɴ ᴜɴᴛᴜᴋ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ',
    segel: 'ᴍᴀᴀꜰ ᴄᴏᴍᴍᴀɴᴅ ɪɴɪ ᴛɪᴅᴀᴋ ʙɪꜱᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴋᴀʀɴᴀ ʀᴀᴡᴀɴ ʙᴀɴɴᴇᴅ !!',
    onlyprem: 'ʜᴀɴʏᴀ ᴜꜱᴇʀ *ᴘʀᴇᴍɪᴜᴍ* ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ꜰɪᴛᴜʀ ɪɴɪ ᴅɪ *ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ* !!',
    nsfw: 'ᴀᴅᴍɪɴ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ғɪᴛᴜʀ *ɴsғᴡ* ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ!',
    rpg: 'ᴀᴅᴍɪɴ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ғɪᴛᴜʀ *ʀᴘɢ ɢᴀᴍᴇ* ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ!',
    game: 'ᴀᴅᴍɪɴ ᴍᴇɴᴏɴᴀᴋᴛɪғᴋᴀɴ ғɪᴛᴜʀ *ɢᴀᴍᴇ* ᴅɪ ɢʀᴏᴜᴘ ɪɴɪ!',
    limitExp: 'ʟɪᴍɪᴛ ᴋᴀᴍᴜ ᴛᴇʟᴀʜ ʜᴀʙɪꜱ ʙᴇʙᴇʀᴀᴘᴀ ᴄᴏᴍᴍᴀɴᴅ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪᴀᴋꜱᴇꜱ! \nᴜɴᴛᴜᴋ ᴍᴇɴᴅᴀᴘᴀᴛᴋᴀɴ ʟɪᴍɪᴛ ᴀɴᴅᴀ ʙɪꜱᴀ ᴍᴇᴍʙᴇʟɪɴʏᴀ ᴅᴇɴɢᴀɴ *#ʙᴜʏ ʟɪᴍɪᴛ* ᴀᴛᴀᴜ ᴍᴇɴᴜɴɢɢᴜ ʟɪᴍɪᴛ ʀᴇꜰʀᴇꜱʜ ꜱᴇᴛɪᴀᴘ ʜᴀʀɪ.',
    restrict: 'ꜰɪᴛᴜʀ ɪɴɪ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ !!',
    unreg: 'sɪʟᴀʜᴋᴀɴ ᴅᴀғᴛᴀʀ ᴋᴇ *ᴅᴀᴛᴀʙᴀsᴇ* ʙᴏᴛ ᴛᴇʀʟᴇʙɪʜ ᴅᴀʜᴜʟᴜ ᴊɪᴋᴀ ɪɴɢɪɴ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ғɪᴛᴜʀ ɪɴɪ!\n\nᴄᴏɴᴛᴏʜ:\n#ᴅᴀғᴛᴀʀ ɴᴀᴍᴀᴍᴜ.ᴜᴍᴜʀᴍᴜ'
  }
};

/*========== PTERODACTYL =======*/

global.domain = 'https://paneltyo.cifumo.biz.id'

global.a_apikey = 'ptla_OYPSKDcDWJcYenARQns000aWWONZzRLi7BXkqIKDDXT';

global.c_apikey = 'ptlc_ExQpzWMtjgdeKzhUTECwWxkeit75KOvtmXl7YtHl0Hg'

let asu = JSON.parse(fs.readFileSync('./lib/datapanel.json'))

global.dbpanel = asu

/*========MongoDb==========*/
global.mongodb ="-" //Kalo gada om apus aja jadi mongodb = "-"
global.dbName = "fearless" // ini mau di ganti juga gapapa soalnya ini nama databasenya hehe
/*================*/

global.wait = global.loading;
global.rose = 'cDNWfULJNfbrmt6dlSDOW01XX64HsTAiMPkA63II7u4SYIum5d0KSzywHRmfTiHl'
global.APIs = {
  // API Prefix
  maelyn: "https://api.maelyn.tech",
  zeltoria: "https://api.zeltoria.my.id",
  xteam: "https://api.xteam.xyz",
  lol: "https://api.lolhuman.xyz",
  males: "https://malesin.xyz",
  zein: "https://api.zahwazein.xyz",
  rose: "https://api.itsrose.rest",
  xzn: "https://skizo.tech",
  saipul: "https://saipulanuar.cf",
  emi: "https://rest.cifumo.biz.id"
};

//Thumbnail m.reply
global.thumbreply = ['https://tinyurl.com/2yvzhxpg','https://tinyurl.com/27rsjlkz', 'https://tinyurl.com/224nk2s9', 'https://tinyurl.com/ymrvhyz5']

global.APIKeys = {
  // APIKey Here
  // 'https://website': 'apikey'
  "https://api.maelyn.tech": "Rk-Ruka",
  "https://api.zeltoria.my.id": "Elistz",
  "https://api.zahwazein.xyz": "zenzkey_8bb60993ae",
  "https://api.xteam.xyz": "cristian9407",
  "https://api.lolhuman.xyz": "RyAPI",
  "https://api.itsrose.rest": "cDNWfULJNfbrmt6dlSDOW01XX64HsTAiMPkA63II7u4SYIum5d0KSzywHRmfTiHl",
  "https://skizo.tech": "cifumo",
};
/*============== INFO OWNER ==============*/
global.link = {
  ig: "https://instagram.com/Itzmeesukaayam",
  gh: "https://github.com/Denz4all",
  gc: "https://chat.whatsapp.com/CpMCB2BU5lqCurBmSzd0pU",
  web: "-",
  nh: "https://nhentai.net/g/365296/",
};

/*============== PAYMENT ==============*/
global.pay = {
  dana: "087815194609",
  ovo: "087815194609",
  gopay: "087815194609",
  pulsa: "087815194609",
  qris: "-",
};
//allfake
global.sig = "https://instagram.com/Itzmeesukaayam";
global.tautanwa = "https://wa.me/6287815194609/";
global.sgh = "https://github.com/Denz4all"; //githu
global.sgc = "https://chat.whatsapp.com/CpMCB2BU5lqCurBmSzd0pU";//group whatsapp
global.chid = '120363316338549180@newsletter'
global.sdc = "-"; //discord
global.botdate = `⫹⫺ DATE: 99999 9999\n⫹⫺ 𝗧𝗶𝗺𝗲:999999`;
global.linkyt = "-";
global.syt = "-";
global.sfb = "-"; // facebook
global.snh = "https://chat.whatsapp.com/6287815194609";
global.thumb = "https://pomf2.lain.la/f/gq4lwdw.jpg"; //isi aja untuk thumbnail default
//============== PROXY ============
global.proxy = 'https://proxy.scrapeops.io/v1/?api_key=9bcd9402-72c9-4a33-af18-16c9275edb9b&url='
/*============== NOMOR ==============*/
global.info = {
  nomorbot: "6287854403765",
  nomorown: "6287815194609",
  namebot: "Seo nari - Bot",
  nameown: "Itzmee",
};
/*============== WATERMARK ==============*/
global.wm = "Seo nari "; //Main Watermark
global.author = "Seo nari-Bot";

/*============== TEXT ==============*/
global.wait = "_Tunggu sebentar kak ^^_, _Choto matte kudasai..._";

/*=========== TYPE DOCUMENT ===========*/
global.doc = {
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  pdf: "application/pdf",
  rtf: "text/rtf",
};

/*============== STICKER WM ==============*/
global.stickpack = "Made With";
global.stickauth = "Raveliaa";

global.multiplier = 38; // The higher, The harder levelup
//hiasan
global.htjava = "乂";
global.htki = htjava + "───『";
global.htka = "』───" + htjava;

/*========== tags premium dan limit =========*/
global.lopr = "🅟";
global.lolm = "🅛";

/*========== HIASAN ===========*/
global.decor = {
  menut: "❏═┅═━–〈",
  menub: "┊•",
  menub2: "┊",
  menuf: "┗––––––––––✦",
  hiasan: "꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷ ͝ ꒦ ͝ ꒷",

  menut: "––––––『",
  menuh: "』––––––",
  menub: "┊☃︎ ",
  menuf: "┗━═┅═━––––––๑\n",
  menua: "",
  menus: "☃︎",

  htki: "––––––『",
  htka: "』––––––",
  haki: "┅━━━═┅═❏",
  haka: "❏═┅═━━━┅",
  lopr: "Ⓟ",
  lolm: "Ⓛ",
  htjava: "❃",
};
/*============== EMOJI ==============*/
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
    let emot = {
      level: "📊",
      limit: "🎫",
      health: "❤️",
      exp: "✨",
      atm: "💳",
      money: "💰",
      bank: "🏦",
      potion: "🥤",
      diamond: "💎",
      common: "📦",
      uncommon: "🛍️",
      mythic: "🎁",
      legendary: "🗃️",
      superior: "💼",
      pet: "🔖",
      trash: "🗑",
      armor: "🥼",
      sword: "⚔️",
      pickaxe: "⛏️",
      fishingrod: "🎣",
      wood: "🪵",
      rock: "🪨",
      string: "🕸️",
      horse: "🐴",
      cat: "🐱",
      dog: "🐶",
      fox: "🦊",
      robo: "🤖",
      petfood: "🍖",
      iron: "⛓️",
      gold: "🪙",
      emerald: "❇️",
      upgrader: "🧰",
      bibitanggur: "🌱",
      bibitjeruk: "🌿",
      bibitapel: "☘️",
      bibitmangga: "🍀",
      bibitpisang: "🌴",
      anggur: "🍇",
      jeruk: "🍊",
      apel: "🍎",
      mangga: "🥭",
      pisang: "🍌",
      botol: "🍾",
      kardus: "📦",
      kaleng: "🏮",
      plastik: "📜",
      gelas: "🧋",
      chip: "♋",
      umpan: "🪱",
      skata: "🧩",
    };
    let results = Object.keys(emot)
      .map((v) => [v, new RegExp(v, "gi")])
      .filter((v) => v[1].test(string));
    if (!results.length) return "";
    else return emot[results[0][0]];
  },
};

//------ JANGAN DIUBAH -----
let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
  unwatchFile(file);
  console.log(chalk.redBright("Update 'config.js'"));
  import(`${file}?update=${Date.now()}`);
});