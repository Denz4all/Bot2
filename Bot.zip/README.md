# Emilia-MD

![Emilia-MD](https://user-images.githubusercontent.com/your-image-path.gif) <!-- Tambahkan link animasi yang sesuai -->

## 📖 Introduction
**Emilia-MD** adalah bot WhatsApp multi-fungsi yang dikembangkan dengan teknologi terbaru untuk membantu Anda mengelola pesan, mengotomatisasi tugas, dan banyak lagi. Bot ini dirancang untuk mudah dikonfigurasi dan digunakan oleh semua kalangan, dengan banyak fitur yang dapat disesuaikan.

## 📜 Rules
Untuk menjaga penggunaan bot ini tetap aman dan sesuai aturan, harap ikuti aturan berikut:

1. **Dilarang membagikan script ini**. Jika Anda ketahuan membagikan script ini tanpa izin, sanksi akan diberikan sesuai kebijakan.
2. **Rubahlah MongoDB URL dan nomor di `config.js`**. Pastikan Anda mengganti `MONGO_URL` dan `NUMBER` dengan data Anda sendiri sebelum menggunakan bot.
3. **Jaga keamanan informasi pribadi**. Jangan menyimpan atau membagikan informasi pribadi atau sensitif menggunakan bot ini.
4. **Gunakan bot dengan bijak**. Hindari penggunaan bot untuk tindakan yang melanggar hukum atau merugikan orang lain.
5. **Kontribusi dan Modifikasi**. Anda boleh memodifikasi bot ini untuk penggunaan pribadi, namun tetap patuhi aturan nomor 1.

## 🔧 Installation
Untuk memasang bot ini, ikuti langkah-langkah berikut:

1. Clone repository ini:  
   ```bash
   git clone https://github.com/cifumo/emilia2.0.git
   ```

2. Masuk ke direktori bot:  
   ```bash
   cd Emilia-MD
   ```

3. Install dependencies:  
   ```bash
   npm install
   ```

4. Konfigurasi bot dengan mengedit file `config.js`:  
   - Ganti `MONGO_URL` dengan MongoDB URL Anda.
   - Ganti `NUMBER` dengan nomor telepon yang akan digunakan oleh bot.

5. Jalankan bot:  
   ```bash
   npm start
   ```

## 💡 Features
**Emilia-MD** memiliki berbagai fitur yang dirancang untuk berbagai kebutuhan pengguna:

### 🔰 Group Features
- **Group Management**: Menambah, menghapus, atau mengelola anggota grup.
- **Welcome Messages**: Kirim pesan sambutan otomatis untuk anggota baru.
- **Anti-Link**: Blokir tautan yang tidak diinginkan dalam grup.

### 👑 Owner Features
- **Broadcast Messages**: Kirim pesan siaran ke semua pengguna.
- **Block/Unblock Users**: Kelola daftar blokir pengguna.
- **Shutdown Bot**: Matikan bot kapan saja.

### 🛠 Tool Features
- **Sticker Maker**: Buat stiker dari gambar atau video.
- **QR Code Generator**: Buat kode QR untuk berbagai keperluan.
- **Text to Speech**: Ubah teks menjadi suara.

### 📥 Download Features
- **YouTube Downloader**: Unduh video atau audio dari YouTube.
- **Instagram Downloader**: Unduh gambar dan video dari Instagram.
- **TikTok Downloader**: Unduh video dari TikTok tanpa watermark.

### 🤖 AI Features
- **Animagine**: Menggunakan AI untuk membuat gambar dari deskripsi teks.
- **Gemini AI**: Chatbot AI canggih untuk membantu berbagai kebutuhan.
- **AI Image Generator**: Buat gambar dengan bantuan AI berdasarkan input pengguna.

### 🎮 Game Features
- **Ular Tangga**: Mainkan permainan ular tangga dengan teman.
- **Werewolf**: Permainan role-play di grup.
- **Catur**: Mainkan catur melawan bot atau teman.
- **Tebak Kata**: Game tebak kata dengan berbagai tingkat kesulitan.

### 😄 Fun Features
- **Meme Generator**: Buat dan bagikan meme lucu.
- **Random Jokes**: Dapatkan lelucon acak.
- **Horoscope**: Lihat ramalan zodiak harian Anda.

### 🖼️ Maker Features
- **Logo Maker**: Buat logo keren untuk kebutuhan Anda.
- **Quote Generator**: Buat dan bagikan kutipan inspiratif.
- **Photo Editor**: Edit foto dengan filter dan efek menarik.

## 📦 Dependencies
Bot ini memerlukan beberapa dependensi utama, antara lain:
- `whatsapp-web.js`
- `mongoose`
- `dotenv`
- `axios`
- `puppeteer`
- `sharp` (untuk pembuatan stiker)

## ⚙️ Configuration
Semua konfigurasi utama dilakukan di file `config.js`. Pastikan Anda mengganti nilai default sesuai dengan kebutuhan Anda, terutama MongoDB URL dan nomor telepon.

## 🛠 Troubleshooting
Jika Anda mengalami masalah, coba langkah-langkah berikut:

1. Pastikan semua dependensi terinstal dengan benar.
2. Cek ulang konfigurasi di `config.js`.
3. Periksa log untuk pesan kesalahan yang bisa membantu mengidentifikasi masalah.

## 📄 License
Proyek ini dilisensikan di bawah [MIT License](LICENSE).