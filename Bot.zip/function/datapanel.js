/*import fs from 'fs';
  // Membaca file JSON dan mengubahnya menjadi objek JavaScript
  const jsonString = fs.readFileSync('./database/datapanel.json', 'utf8');
  let anu = JSON.parse(jsonString);

export function addDataPanel(nohp, userid, serverid, exppanel, srvid, ram, cpu, disk, admin, notif) {


  // Menambahkan objek "result"
  anu.panel = Object.assign(anu.panel, {
    [userid]: {
	"nohp": nohp,
      "userid": userid,
      "serverid": serverid,
      "exppanel": exppanel,
      "srvid": srvid,
	  "ram": ram,
	  "cpu": cpu,
	  "disk": disk,
	  "admin": admin,
      "notif": notif,

    }
  });

  // Menulis perubahan ke file JSON
  fs.writeFileSync('./database/datapanel.json', JSON.stringify(anu));
}

export function editExppanel(userid, newExppanel) {
  
  const data = JSON.parse(jsonString);
  const panel = data.panel;

  if (panel[userid]) {
    panel[userid].exppanel = newExppanel;
    fs.writeFileSync('./database/datapanel.json', JSON.stringify(data));
    console.log(`exppanel for user ${userid} updated to ${newExppanel}`);
  } else {
    console.log(`user ${userid} not found in datapanel.json`);
  }
}

// Menggunakan fs.watchFile()
fs.watchFile('./database/datapanel.json', (curr, prev) => {
  // Membaca file JSON dan mengubahnya menjadi objek JavaScript
  const jsonString = fs.readFileSync('./database/datapanel.json', 'utf8');
  let anu = JSON.parse(jsonString);
  console.log(anu);
});

// Menghapus pemantauan file saat aplikasi dihentikan
process.on('SIGINT', () => {
  fs.unwatchFile('./database/datapanel.json');
  process.exit();
});

export default {
    addDataPanel
}*/

export function addDataPanel(nohp, userid, serverid, exppanel, srvid, ram, cpu, disk, admin, notif) {
  // Menambahkan objek "result" ke global.db.data.bots.panel
  global.db.data.bots.panel = Object.assign(global.db.data.bots.panel || {}, {
    [userid]: {
      "nohp": nohp,
      "userid": userid,
      "serverid": serverid,
      "exppanel": exppanel,
      "srvid": srvid,
      "ram": ram,
      "cpu": cpu,
      "disk": disk,
      "admin": admin,
      "notif": notif,
    }
  });
}

export function editExppanel(userid, newExppanel) {
  const panel = global.db.data.bots.panel;

  if (panel[userid]) {
    panel[userid].exppanel = newExppanel;
    console.log(`exppanel for user ${userid} updated to ${newExppanel}`);
  } else {
    console.log(`user ${userid} not found in global.db.data.bots.panel`);
  }
}

// Menghapus pemantauan file saat aplikasi dihentikan
process.on('SIGINT', () => {
  process.exit();
});

export default {
  addDataPanel
};